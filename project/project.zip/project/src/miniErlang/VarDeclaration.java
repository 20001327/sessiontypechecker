package miniErlang;

import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast class
 * @aspect NameAnalisys
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:4
 */
 class VarDeclaration extends java.lang.Object {
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:5
   */
  
        String name;
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:6
   */
  
        Session type;
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:7
   */
  
        Expression value;
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:9
   */
  

        public String getName(){
            return name;
        }
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:13
   */
  

        public Session getType(){
            return type;
        }
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:17
   */
  

        public Expression getValue(){
            return value;
        }
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:21
   */
  

        public void setName(String name){
            this.name = name;
        }
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:25
   */
  

        public void setType(Session type){
            this.type = type;
        }
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:29
   */
  

        public void setValue(Expression value){
            this.value = value;
        }

}
