/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\FErlang.ast:9
 * @astdecl Anno : ASTNode ::= <Line:Integer> <StartToken:Integer>;
 * @production Anno : {@link ASTNode} ::= <span class="component">&lt;Line:{@link Integer}&gt;</span> <span class="component">&lt;StartToken:{@link Integer}&gt;</span>;

 */
public class Anno extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @declaredat ASTNode:1
   */
  public Anno() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
  }
  /**
   * @declaredat ASTNode:12
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Line", "StartToken"},
    type = {"Integer", "Integer"},
    kind = {"Token", "Token"}
  )
  public Anno(Integer p0, Integer p1) {
    setLine(p0);
    setStartToken(p1);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:22
   */
  protected int numChildren() {
    return 0;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:26
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:31
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:36
   */
  public Anno clone() throws CloneNotSupportedException {
    Anno node = (Anno) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:41
   */
  public Anno copy() {
    try {
      Anno node = (Anno) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:60
   */
  @Deprecated
  public Anno fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:70
   */
  public Anno treeCopyNoTransform() {
    Anno tree = (Anno) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:90
   */
  public Anno treeCopy() {
    Anno tree = (Anno) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the lexeme Line.
   * @param value The new value for the lexeme Line.
   * @apilevel high-level
   */
  public Anno setLine(Integer value) {
    tokenInteger_Line = value;
    return this;
  }
  /** @apilevel internal 
   */
  protected Integer tokenInteger_Line;
  /**
   * Retrieves the value for the lexeme Line.
   * @return The value for the lexeme Line.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="Line")
  public Integer getLine() {
    return tokenInteger_Line;
  }
  /**
   * Replaces the lexeme StartToken.
   * @param value The new value for the lexeme StartToken.
   * @apilevel high-level
   */
  public Anno setStartToken(Integer value) {
    tokenInteger_StartToken = value;
    return this;
  }
  /** @apilevel internal 
   */
  protected Integer tokenInteger_StartToken;
  /**
   * Retrieves the value for the lexeme StartToken.
   * @return The value for the lexeme StartToken.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="StartToken")
  public Integer getStartToken() {
    return tokenInteger_StartToken;
  }

}
