/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\FErlang.ast:25
 * @astdecl Expression : ASTNode;
 * @production Expression : {@link ASTNode};

 */
public abstract class Expression extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:395
   */
  public void print(){
       printer().append("exp");
    }
  /**
   * @declaredat ASTNode:1
   */
  public Expression() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:13
   */
  protected int numChildren() {
    return 0;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:17
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    getFunctionss_reset();
    getFunType_reset();
    getModuleName_reset();
    printer_reset();
    getDeclarations_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:26
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:31
   */
  public Expression clone() throws CloneNotSupportedException {
    Expression node = (Expression) super.clone();
    return node;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:42
   */
  @Deprecated
  public abstract Expression fullCopy();
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:50
   */
  public abstract Expression treeCopyNoTransform();
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:58
   */
  public abstract Expression treeCopy();
  /**
   * @attribute syn
   * @aspect ExpressionTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:4
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ExpressionTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:4")
  public abstract Session type();
  /**
   * @attribute inh
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:16
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:16")
  public String getCalledFunName() {
    if (getCalledFunName_visited) {
      throw new RuntimeException("Circular definition of attribute Expression.getCalledFunName().");
    }
    getCalledFunName_visited = true;
    String getCalledFunName_value = getParent().Define_getCalledFunName(this, null);
    getCalledFunName_visited = false;
    return getCalledFunName_value;
  }
/** @apilevel internal */
protected boolean getCalledFunName_visited = false;
  /**
   * @attribute inh
   * @aspect ExpressionTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ExpressionTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:3")
  public List<Function> getFunctionss() {
    ASTState state = state();
    if (getFunctionss_computed) {
      return getFunctionss_value;
    }
    if (getFunctionss_visited) {
      throw new RuntimeException("Circular definition of attribute Expression.getFunctionss().");
    }
    getFunctionss_visited = true;
    state().enterLazyAttribute();
    getFunctionss_value = getParent().Define_getFunctionss(this, null);
    getFunctionss_computed = true;
    state().leaveLazyAttribute();
    getFunctionss_visited = false;
    return getFunctionss_value;
  }
/** @apilevel internal */
protected boolean getFunctionss_visited = false;
  /** @apilevel internal */
  private void getFunctionss_reset() {
    getFunctionss_computed = false;
    
    getFunctionss_value = null;
    getFunctionss_visited = false;
  }
  /** @apilevel internal */
  protected boolean getFunctionss_computed = false;

  /** @apilevel internal */
  protected List<Function> getFunctionss_value;

  /**
   * @attribute inh
   * @aspect ExpressionTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:5
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ExpressionTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:5")
  public FunType getFunType() {
    ASTState state = state();
    if (getFunType_computed) {
      return getFunType_value;
    }
    if (getFunType_visited) {
      throw new RuntimeException("Circular definition of attribute Expression.getFunType().");
    }
    getFunType_visited = true;
    state().enterLazyAttribute();
    getFunType_value = getParent().Define_getFunType(this, null);
    getFunType_computed = true;
    state().leaveLazyAttribute();
    getFunType_visited = false;
    return getFunType_value;
  }
/** @apilevel internal */
protected boolean getFunType_visited = false;
  /** @apilevel internal */
  private void getFunType_reset() {
    getFunType_computed = false;
    
    getFunType_value = null;
    getFunType_visited = false;
  }
  /** @apilevel internal */
  protected boolean getFunType_computed = false;

  /** @apilevel internal */
  protected FunType getFunType_value;

  /**
   * @attribute inh
   * @aspect ExpressionTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:6
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ExpressionTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:6")
  public String getModuleName() {
    ASTState state = state();
    if (getModuleName_computed) {
      return getModuleName_value;
    }
    if (getModuleName_visited) {
      throw new RuntimeException("Circular definition of attribute Expression.getModuleName().");
    }
    getModuleName_visited = true;
    state().enterLazyAttribute();
    getModuleName_value = getParent().Define_getModuleName(this, null);
    getModuleName_computed = true;
    state().leaveLazyAttribute();
    getModuleName_visited = false;
    return getModuleName_value;
  }
/** @apilevel internal */
protected boolean getModuleName_visited = false;
  /** @apilevel internal */
  private void getModuleName_reset() {
    getModuleName_computed = false;
    
    getModuleName_value = null;
    getModuleName_visited = false;
  }
  /** @apilevel internal */
  protected boolean getModuleName_computed = false;

  /** @apilevel internal */
  protected String getModuleName_value;

  /**
   * @attribute inh
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:63
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:63")
  public PrettyPrinter printer() {
    ASTState state = state();
    if (printer_computed) {
      return printer_value;
    }
    if (printer_visited) {
      throw new RuntimeException("Circular definition of attribute Expression.printer().");
    }
    printer_visited = true;
    state().enterLazyAttribute();
    printer_value = getParent().Define_printer(this, null);
    printer_computed = true;
    state().leaveLazyAttribute();
    printer_visited = false;
    return printer_value;
  }
/** @apilevel internal */
protected boolean printer_visited = false;
  /** @apilevel internal */
  private void printer_reset() {
    printer_computed = false;
    
    printer_value = null;
    printer_visited = false;
  }
  /** @apilevel internal */
  protected boolean printer_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter printer_value;

  /**
   * @attribute inh
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:58
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="NameAnalisys", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:58")
  public ArrayList<VarDeclaration> getDeclarations() {
    ASTState state = state();
    if (getDeclarations_computed) {
      return getDeclarations_value;
    }
    if (getDeclarations_visited) {
      throw new RuntimeException("Circular definition of attribute Expression.getDeclarations().");
    }
    getDeclarations_visited = true;
    state().enterLazyAttribute();
    getDeclarations_value = getParent().Define_getDeclarations(this, null);
    getDeclarations_computed = true;
    state().leaveLazyAttribute();
    getDeclarations_visited = false;
    return getDeclarations_value;
  }
/** @apilevel internal */
protected boolean getDeclarations_visited = false;
  /** @apilevel internal */
  private void getDeclarations_reset() {
    getDeclarations_computed = false;
    
    getDeclarations_value = null;
    getDeclarations_visited = false;
  }
  /** @apilevel internal */
  protected boolean getDeclarations_computed = false;

  /** @apilevel internal */
  protected ArrayList<VarDeclaration> getDeclarations_value;


}
