/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\FErlang.ast:8
 * @astdecl Function : ASTNode ::= [Type:FunType] <FunctionName:String> Parameters:Variable* Body:Process;
 * @production Function : {@link ASTNode} ::= <span class="component">[Type:{@link FunType}]</span> <span class="component">&lt;FunctionName:{@link String}&gt;</span> <span class="component">Parameters:{@link Variable}*</span> <span class="component">Body:{@link Process}</span>;

 */
public class Function extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @aspect SessionTypesInformationUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:11
   */
  public boolean isRecursive(){
        return getType().getSessionType() instanceof RecType;
    }
  /**
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:101
   */
  public void print() {

        if(hasType()){
            getType().print();
        }

        printer().append("\n" + getFunctionName() + "(");
        for (int i=0; i<getNumParameters(); i++) {
            Variable var = getParameters(i);
            printer().append(var.getIdent());
            if(i<getNumParameters()-1){
                printer().append(",");
            }
        }
        printer().append(")->");
        getBody().print();
        printer().append(".");
    }
  /**
   * @aspect TypeTable
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:33
   */
  public void addTypeDeclaration(String name, Session type) {
        TypeDeclaration var = new TypeDeclaration();
        var.setName(name);
        var.setType(type);
        getTypeDeclarations().add(var);
    }
  /**
   * @declaredat ASTNode:1
   */
  public Function() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[3];
    setChild(new Opt(), 0);
    setChild(new List(), 1);
  }
  /**
   * @declaredat ASTNode:15
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Type", "FunctionName", "Parameters", "Body"},
    type = {"Opt<FunType>", "String", "List<Variable>", "Process"},
    kind = {"Opt", "Token", "List", "Child"}
  )
  public Function(Opt<FunType> p0, String p1, List<Variable> p2, Process p3) {
    setChild(p0, 0);
    setFunctionName(p1);
    setChild(p2, 1);
    setChild(p3, 2);
  }
  /**
   * @declaredat ASTNode:26
   */
  public Function(Opt<FunType> p0, beaver.Symbol p1, List<Variable> p2, Process p3) {
    setChild(p0, 0);
    setFunctionName(p1);
    setChild(p2, 1);
    setChild(p3, 2);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:33
   */
  protected int numChildren() {
    return 3;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:37
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    getInfo_String_int_reset();
    getDeclarations_reset();
    printer_reset();
    getTypeDeclarations_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:45
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:50
   */
  public Function clone() throws CloneNotSupportedException {
    Function node = (Function) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:55
   */
  public Function copy() {
    try {
      Function node = (Function) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:74
   */
  @Deprecated
  public Function fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:84
   */
  public Function treeCopyNoTransform() {
    Function tree = (Function) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:104
   */
  public Function treeCopy() {
    Function tree = (Function) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the optional node for the Type child. This is the <code>Opt</code>
   * node containing the child Type, not the actual child!
   * @param opt The new node to be used as the optional node for the Type child.
   * @apilevel low-level
   */
  public Function setTypeOpt(Opt<FunType> opt) {
    setChild(opt, 0);
    return this;
  }
  /**
   * Replaces the (optional) Type child.
   * @param node The new node to be used as the Type child.
   * @apilevel high-level
   */
  public Function setType(FunType node) {
    getTypeOpt().setChild(node, 0);
    return this;
  }
  /**
   * Check whether the optional Type child exists.
   * @return {@code true} if the optional Type child exists, {@code false} if it does not.
   * @apilevel high-level
   */
  public boolean hasType() {
    return getTypeOpt().getNumChild() != 0;
  }
  /**
   * Retrieves the (optional) Type child.
   * @return The Type child, if it exists. Returns {@code null} otherwise.
   * @apilevel low-level
   */
  public FunType getType() {
    return (FunType) getTypeOpt().getChild(0);
  }
  /**
   * Retrieves the optional node for the Type child. This is the <code>Opt</code> node containing the child Type, not the actual child!
   * @return The optional node for child the Type child.
   * @apilevel low-level
   */
  @ASTNodeAnnotation.OptChild(name="Type")
  public Opt<FunType> getTypeOpt() {
    return (Opt<FunType>) getChild(0);
  }
  /**
   * Retrieves the optional node for child Type. This is the <code>Opt</code> node containing the child Type, not the actual child!
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The optional node for child Type.
   * @apilevel low-level
   */
  public Opt<FunType> getTypeOptNoTransform() {
    return (Opt<FunType>) getChildNoTransform(0);
  }
  /**
   * Replaces the lexeme FunctionName.
   * @param value The new value for the lexeme FunctionName.
   * @apilevel high-level
   */
  public Function setFunctionName(String value) {
    tokenString_FunctionName = value;
    return this;
  }
  /** @apilevel internal 
   */
  protected String tokenString_FunctionName;
  /**
   */
  public int FunctionNamestart;
  /**
   */
  public int FunctionNameend;
  /**
   * JastAdd-internal setter for lexeme FunctionName using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme FunctionName
   * @apilevel internal
   */
  public Function setFunctionName(beaver.Symbol symbol) {
    if (symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setFunctionName is only valid for String lexemes");
    tokenString_FunctionName = (String)symbol.value;
    FunctionNamestart = symbol.getStart();
    FunctionNameend = symbol.getEnd();
    return this;
  }
  /**
   * Retrieves the value for the lexeme FunctionName.
   * @return The value for the lexeme FunctionName.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="FunctionName")
  public String getFunctionName() {
    return tokenString_FunctionName != null ? tokenString_FunctionName : "";
  }
  /**
   * Replaces the Parameters list.
   * @param list The new list node to be used as the Parameters list.
   * @apilevel high-level
   */
  public Function setParametersList(List<Variable> list) {
    setChild(list, 1);
    return this;
  }
  /**
   * Retrieves the number of children in the Parameters list.
   * @return Number of children in the Parameters list.
   * @apilevel high-level
   */
  public int getNumParameters() {
    return getParametersList().getNumChild();
  }
  /**
   * Retrieves the number of children in the Parameters list.
   * Calling this method will not trigger rewrites.
   * @return Number of children in the Parameters list.
   * @apilevel low-level
   */
  public int getNumParametersNoTransform() {
    return getParametersListNoTransform().getNumChildNoTransform();
  }
  /**
   * Retrieves the element at index {@code i} in the Parameters list.
   * @param i Index of the element to return.
   * @return The element at position {@code i} in the Parameters list.
   * @apilevel high-level
   */
  public Variable getParameters(int i) {
    return (Variable) getParametersList().getChild(i);
  }
  /**
   * Check whether the Parameters list has any children.
   * @return {@code true} if it has at least one child, {@code false} otherwise.
   * @apilevel high-level
   */
  public boolean hasParameters() {
    return getParametersList().getNumChild() != 0;
  }
  /**
   * Append an element to the Parameters list.
   * @param node The element to append to the Parameters list.
   * @apilevel high-level
   */
  public Function addParameters(Variable node) {
    List<Variable> list = (parent == null) ? getParametersListNoTransform() : getParametersList();
    list.addChild(node);
    return this;
  }
  /** @apilevel low-level 
   */
  public Function addParametersNoTransform(Variable node) {
    List<Variable> list = getParametersListNoTransform();
    list.addChild(node);
    return this;
  }
  /**
   * Replaces the Parameters list element at index {@code i} with the new node {@code node}.
   * @param node The new node to replace the old list element.
   * @param i The list index of the node to be replaced.
   * @apilevel high-level
   */
  public Function setParameters(Variable node, int i) {
    List<Variable> list = getParametersList();
    list.setChild(node, i);
    return this;
  }
  /**
   * Retrieves the Parameters list.
   * @return The node representing the Parameters list.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.ListChild(name="Parameters")
  public List<Variable> getParametersList() {
    List<Variable> list = (List<Variable>) getChild(1);
    return list;
  }
  /**
   * Retrieves the Parameters list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Parameters list.
   * @apilevel low-level
   */
  public List<Variable> getParametersListNoTransform() {
    return (List<Variable>) getChildNoTransform(1);
  }
  /**
   * @return the element at index {@code i} in the Parameters list without
   * triggering rewrites.
   */
  public Variable getParametersNoTransform(int i) {
    return (Variable) getParametersListNoTransform().getChildNoTransform(i);
  }
  /**
   * Retrieves the Parameters list.
   * @return The node representing the Parameters list.
   * @apilevel high-level
   */
  public List<Variable> getParameterss() {
    return getParametersList();
  }
  /**
   * Retrieves the Parameters list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Parameters list.
   * @apilevel low-level
   */
  public List<Variable> getParameterssNoTransform() {
    return getParametersListNoTransform();
  }
  /**
   * Replaces the Body child.
   * @param node The new node to replace the Body child.
   * @apilevel high-level
   */
  public Function setBody(Process node) {
    setChild(node, 2);
    return this;
  }
  /**
   * Retrieves the Body child.
   * @return The current node used as the Body child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Body")
  public Process getBody() {
    return (Process) getChild(2);
  }
  /**
   * Retrieves the Body child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Body child.
   * @apilevel low-level
   */
  public Process getBodyNoTransform() {
    return (Process) getChildNoTransform(2);
  }
/** @apilevel internal */
protected boolean getInferredType_visited = false;
  /**
   * @attribute syn
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:23
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:23")
  public Session getInferredType() {
    if (getInferredType_visited) {
      throw new RuntimeException("Circular definition of attribute Function.getInferredType().");
    }
    getInferredType_visited = true;
    try {
            Session s = null;
            for(TypeDeclaration decl: getTypeDeclarations()){
                if(decl.getName().equals("fun-"+getFunctionName())){
                    s = decl.getType();
                }
            }
            if(s==null){
                s = getBody().type();
                RecVar var = new RecVar(getFunctionName());
                if(isRecursive() && s.endsWith(var)){
                   s = new RecType(var, s);
                }
                addTypeDeclaration("fun-"+getFunctionName(),s);
            }
            return s;
        }
    finally {
      getInferredType_visited = false;
    }
  }
/** @apilevel internal */
protected java.util.Set getInfo_String_int_visited;
  /** @apilevel internal */
  private void getInfo_String_int_reset() {
    getInfo_String_int_values = null;
    getInfo_String_int_visited = null;
  }
  /** @apilevel internal */
  protected java.util.Map getInfo_String_int_values;

  /**
   * @attribute syn
   * @aspect SessionTypesInformationUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:7
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="SessionTypesInformationUtility", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:7")
  public Session getInfo(String label, int index) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(label);
    _parameters.add(index);
    if (getInfo_String_int_visited == null) getInfo_String_int_visited = new java.util.HashSet(4);
    if (getInfo_String_int_values == null) getInfo_String_int_values = new java.util.HashMap(4);
    ASTState state = state();
    if (getInfo_String_int_values.containsKey(_parameters)) {
      return (Session) getInfo_String_int_values.get(_parameters);
    }
    if (getInfo_String_int_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Function.getInfo(String,int).");
    }
    getInfo_String_int_visited.add(_parameters);
    state().enterLazyAttribute();
    Session getInfo_String_int_value = getInfo_compute(label, index);
    getInfo_String_int_values.put(_parameters, getInfo_String_int_value);
    state().leaveLazyAttribute();
    getInfo_String_int_visited.remove(_parameters);
    return getInfo_String_int_value;
  }
  /** @apilevel internal */
  private Session getInfo_compute(String label, int index) {
          return getType().getSessionType().getInfo(label, index);
      }
/** @apilevel internal */
protected boolean addsIndentationLevel_visited = false;
  /**
   * @attribute syn
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:47
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:44")
  public boolean addsIndentationLevel() {
    if (addsIndentationLevel_visited) {
      throw new RuntimeException("Circular definition of attribute ASTNode.addsIndentationLevel().");
    }
    addsIndentationLevel_visited = true;
    boolean addsIndentationLevel_value = true;
    addsIndentationLevel_visited = false;
    return addsIndentationLevel_value;
  }
/** @apilevel internal */
protected boolean getDeclarations_visited = false;
  /** @apilevel internal */
  private void getDeclarations_reset() {
    getDeclarations_computed = false;
    
    getDeclarations_value = null;
    getDeclarations_visited = false;
  }
  /** @apilevel internal */
  protected boolean getDeclarations_computed = false;

  /** @apilevel internal */
  protected ArrayList<VarDeclaration> getDeclarations_value;

  /**
   * @attribute syn
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:34
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="NameAnalisys", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:34")
  public ArrayList<VarDeclaration> getDeclarations() {
    ASTState state = state();
    if (getDeclarations_computed) {
      return getDeclarations_value;
    }
    if (getDeclarations_visited) {
      throw new RuntimeException("Circular definition of attribute Function.getDeclarations().");
    }
    getDeclarations_visited = true;
    state().enterLazyAttribute();
    getDeclarations_value = getDeclarations_compute();
    getDeclarations_computed = true;
    state().leaveLazyAttribute();
    getDeclarations_visited = false;
    return getDeclarations_value;
  }
  /** @apilevel internal */
  private ArrayList<VarDeclaration> getDeclarations_compute() {
          return new ArrayList<>();
      }
  /**
   * @attribute inh
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:60
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:60")
  public PrettyPrinter printer() {
    ASTState state = state();
    if (printer_computed) {
      return printer_value;
    }
    if (printer_visited) {
      throw new RuntimeException("Circular definition of attribute Function.printer().");
    }
    printer_visited = true;
    state().enterLazyAttribute();
    printer_value = getParent().Define_printer(this, null);
    printer_computed = true;
    state().leaveLazyAttribute();
    printer_visited = false;
    return printer_value;
  }
/** @apilevel internal */
protected boolean printer_visited = false;
  /** @apilevel internal */
  private void printer_reset() {
    printer_computed = false;
    
    printer_value = null;
    printer_visited = false;
  }
  /** @apilevel internal */
  protected boolean printer_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter printer_value;

  /**
   * @attribute inh
   * @aspect TypeTable
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:30
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="TypeTable", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:30")
  public ArrayList<TypeDeclaration> getTypeDeclarations() {
    ASTState state = state();
    if (getTypeDeclarations_computed) {
      return getTypeDeclarations_value;
    }
    if (getTypeDeclarations_visited) {
      throw new RuntimeException("Circular definition of attribute Function.getTypeDeclarations().");
    }
    getTypeDeclarations_visited = true;
    state().enterLazyAttribute();
    getTypeDeclarations_value = getParent().Define_getTypeDeclarations(this, null);
    getTypeDeclarations_computed = true;
    state().leaveLazyAttribute();
    getTypeDeclarations_visited = false;
    return getTypeDeclarations_value;
  }
/** @apilevel internal */
protected boolean getTypeDeclarations_visited = false;
  /** @apilevel internal */
  private void getTypeDeclarations_reset() {
    getTypeDeclarations_computed = false;
    
    getTypeDeclarations_value = null;
    getTypeDeclarations_visited = false;
  }
  /** @apilevel internal */
  protected boolean getTypeDeclarations_computed = false;

  /** @apilevel internal */
  protected ArrayList<TypeDeclaration> getTypeDeclarations_value;

  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:5
   * @apilevel internal
   */
  public FunType Define_getFunType(ASTNode _callerNode, ASTNode _childNode) {
    if (_callerNode == getBodyNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:8
      return this.getType();
    }
    else {
      return getParent().Define_getFunType(this, _callerNode);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\ExpressionTypes.jrag:5
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute getFunType
   */
  protected boolean canDefine_getFunType(ASTNode _callerNode, ASTNode _childNode) {
    return true;
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:16
   * @apilevel internal
   */
  public String Define_getCalledFunName(ASTNode _callerNode, ASTNode _childNode) {
    if (_callerNode == getBodyNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:9
      return this.getFunctionName();
    }
    else {
      return getParent().Define_getCalledFunName(this, _callerNode);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:16
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute getCalledFunName
   */
  protected boolean canDefine_getCalledFunName(ASTNode _callerNode, ASTNode _childNode) {
    return true;
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:17
   * @apilevel internal
   */
  public Process Define_getCalledBody(ASTNode _callerNode, ASTNode _childNode) {
    if (_callerNode == getBodyNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:10
      return this.getBody();
    }
    else {
      return getParent().Define_getCalledBody(this, _callerNode);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:17
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute getCalledBody
   */
  protected boolean canDefine_getCalledBody(ASTNode _callerNode, ASTNode _childNode) {
    return true;
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:4
   * @apilevel internal
   */
  public Session Define_getInfo(ASTNode _callerNode, ASTNode _childNode, String label, int index) {
    if (_callerNode == getBodyNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:3
      return this.getInfo(label,index);
    }
    else {
      return getParent().Define_getInfo(this, _callerNode, label, index);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:4
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute getInfo
   */
  protected boolean canDefine_getInfo(ASTNode _callerNode, ASTNode _childNode, String label, int index) {
    return true;
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:57
   * @apilevel internal
   */
  public ArrayList<VarDeclaration> Define_getDeclarations(ASTNode _callerNode, ASTNode _childNode) {
    if (_callerNode == getBodyNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:54
      return this.getDeclarations();
    }
    else {
      return getParent().Define_getDeclarations(this, _callerNode);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:57
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute getDeclarations
   */
  protected boolean canDefine_getDeclarations(ASTNode _callerNode, ASTNode _childNode) {
    return true;
  }

}
