/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\GlobalTypes.ast:5
 * @astdecl CommunicationChoices : Global ::= Communications:Communication*;
 * @production CommunicationChoices : {@link Global} ::= <span class="component">Communications:{@link Communication}*</span>;

 */
public class CommunicationChoices extends Global implements Cloneable {
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:27
   */
  public void stampa(){
        if(getNumCommunications()>1)stampante().append("(");
        for(int i=0;i<getNumCommunications();i++){
            getCommunications(i).stampa();
            if(i<getNumCommunications()-1){
                stampante().append(",");
            }
        }
        if(getNumCommunications()>1)stampante().append(")");

    }
  /**
   * @aspect ActorDiscover
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\ActorDiscover.jrag:17
   */
  public ArrayList<String> actors(){
        ArrayList<String> actors = new ArrayList();
        for(Communication c :  getCommunicationss()){
            for(String actor: c.getMessage().actors()){
                GProg.addAbsent(actor, actors);

                for(String act: c.getNext().actors()){
                    GProg.addAbsent(act, actors);
                }
            }
        }
        return actors;
    }
  /**
   * @declaredat ASTNode:1
   */
  public CommunicationChoices() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[1];
    setChild(new List(), 0);
  }
  /**
   * @declaredat ASTNode:14
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Communications"},
    type = {"List<Communication>"},
    kind = {"List"}
  )
  public CommunicationChoices(List<Communication> p0) {
    setChild(p0, 0);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:23
   */
  protected int numChildren() {
    return 1;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:27
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:32
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:37
   */
  public CommunicationChoices clone() throws CloneNotSupportedException {
    CommunicationChoices node = (CommunicationChoices) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:42
   */
  public CommunicationChoices copy() {
    try {
      CommunicationChoices node = (CommunicationChoices) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:61
   */
  @Deprecated
  public CommunicationChoices fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:71
   */
  public CommunicationChoices treeCopyNoTransform() {
    CommunicationChoices tree = (CommunicationChoices) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:91
   */
  public CommunicationChoices treeCopy() {
    CommunicationChoices tree = (CommunicationChoices) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the Communications list.
   * @param list The new list node to be used as the Communications list.
   * @apilevel high-level
   */
  public CommunicationChoices setCommunicationsList(List<Communication> list) {
    setChild(list, 0);
    return this;
  }
  /**
   * Retrieves the number of children in the Communications list.
   * @return Number of children in the Communications list.
   * @apilevel high-level
   */
  public int getNumCommunications() {
    return getCommunicationsList().getNumChild();
  }
  /**
   * Retrieves the number of children in the Communications list.
   * Calling this method will not trigger rewrites.
   * @return Number of children in the Communications list.
   * @apilevel low-level
   */
  public int getNumCommunicationsNoTransform() {
    return getCommunicationsListNoTransform().getNumChildNoTransform();
  }
  /**
   * Retrieves the element at index {@code i} in the Communications list.
   * @param i Index of the element to return.
   * @return The element at position {@code i} in the Communications list.
   * @apilevel high-level
   */
  public Communication getCommunications(int i) {
    return (Communication) getCommunicationsList().getChild(i);
  }
  /**
   * Check whether the Communications list has any children.
   * @return {@code true} if it has at least one child, {@code false} otherwise.
   * @apilevel high-level
   */
  public boolean hasCommunications() {
    return getCommunicationsList().getNumChild() != 0;
  }
  /**
   * Append an element to the Communications list.
   * @param node The element to append to the Communications list.
   * @apilevel high-level
   */
  public CommunicationChoices addCommunications(Communication node) {
    List<Communication> list = (parent == null) ? getCommunicationsListNoTransform() : getCommunicationsList();
    list.addChild(node);
    return this;
  }
  /** @apilevel low-level 
   */
  public CommunicationChoices addCommunicationsNoTransform(Communication node) {
    List<Communication> list = getCommunicationsListNoTransform();
    list.addChild(node);
    return this;
  }
  /**
   * Replaces the Communications list element at index {@code i} with the new node {@code node}.
   * @param node The new node to replace the old list element.
   * @param i The list index of the node to be replaced.
   * @apilevel high-level
   */
  public CommunicationChoices setCommunications(Communication node, int i) {
    List<Communication> list = getCommunicationsList();
    list.setChild(node, i);
    return this;
  }
  /**
   * Retrieves the Communications list.
   * @return The node representing the Communications list.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.ListChild(name="Communications")
  public List<Communication> getCommunicationsList() {
    List<Communication> list = (List<Communication>) getChild(0);
    return list;
  }
  /**
   * Retrieves the Communications list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Communications list.
   * @apilevel low-level
   */
  public List<Communication> getCommunicationsListNoTransform() {
    return (List<Communication>) getChildNoTransform(0);
  }
  /**
   * @return the element at index {@code i} in the Communications list without
   * triggering rewrites.
   */
  public Communication getCommunicationsNoTransform(int i) {
    return (Communication) getCommunicationsListNoTransform().getChildNoTransform(i);
  }
  /**
   * Retrieves the Communications list.
   * @return The node representing the Communications list.
   * @apilevel high-level
   */
  public List<Communication> getCommunicationss() {
    return getCommunicationsList();
  }
  /**
   * Retrieves the Communications list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Communications list.
   * @apilevel low-level
   */
  public List<Communication> getCommunicationssNoTransform() {
    return getCommunicationsListNoTransform();
  }
/** @apilevel internal */
protected boolean addsIndentationLevel_visited = false;
  /**
   * @attribute syn
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:19
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:44")
  public boolean addsIndentationLevel() {
    if (addsIndentationLevel_visited) {
      throw new RuntimeException("Circular definition of attribute ASTNode.addsIndentationLevel().");
    }
    addsIndentationLevel_visited = true;
    boolean addsIndentationLevel_value = true;
    addsIndentationLevel_visited = false;
    return addsIndentationLevel_value;
  }
/** @apilevel internal */
protected java.util.Set project_String_visited;
  /**
   * @attribute syn
   * @aspect CommunicationChoiceProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\CommunicationChoiceProjection.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="CommunicationChoiceProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\CommunicationChoiceProjection.jadd:3")
  public Session project(String actor) {
    Object _parameters = actor;
    if (project_String_visited == null) project_String_visited = new java.util.HashSet(4);
    if (project_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute CommunicationChoices.project(String).");
    }
    project_String_visited.add(_parameters);
    try {
    
            if(getNumCommunications()==1){
                return getCommunications(0).project(actor);
            }else{
                List<SessionSend> sends = new List();
                List<Session> receives = new List();
                for(Communication c : getCommunicationss()){
                    Session projected = c.project(actor);
                    if(projected.isSubtypeOf(new ExternalChoice())
                        || projected.isSubtypeOf(new SessionReceive())
                        || projected.isSubtypeOf(new End())){
                        receives.add(projected);
                    }else if(projected.isSubtypeOf(new SessionSend())){
                        sends.add((SessionSend) projected);
                    }else{
                        return null;
                    }
                }
    
                if(sends.getNumChild()>0 && receives.getNumChild() == 0){
                    return new InternalChoice(sends);
                }
    
              if(receives.getNumChild()>0 && sends.getNumChild() == 0){
                    List<SessionReceive> lis = Session.merge(receives);
                    if(lis.getNumChild()==1) return lis.getChild(0);
                    else{
                        ExternalChoice ext = new ExternalChoice(lis);
                        if(ext.isWellFormed()){
                            return ext;
                        }
                    }
                }
            }
    
            return null;
    
        }
    finally {
      project_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected java.util.Set projectDelegate_String_String_visited;
  /**
   * @attribute syn
   * @aspect CommunicationChoiceDelegateProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\CommunicationChoiceDelegateProjection.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="CommunicationChoiceDelegateProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\CommunicationChoiceDelegateProjection.jadd:3")
  public Session projectDelegate(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegate_String_String_visited == null) projectDelegate_String_String_visited = new java.util.HashSet(4);
    if (projectDelegate_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute CommunicationChoices.projectDelegate(String,String).");
    }
    projectDelegate_String_String_visited.add(_parameters);
    try {
            if(getNumCommunications()==1){
                return getCommunications(0).projectDelegate(p, q);
            }else{
                List<SessionSend> sends = new List();
                List<Session> receives = new List();
                for(Communication c : getCommunicationss()){
                    Session projected = c.projectDelegate(p,q);
                    if(projected.isSubtypeOf(new ExternalChoice())
                        || projected.isSubtypeOf(new SessionReceive())){
                        receives.add(projected);
                    }else if(projected.isSubtypeOf(new SessionSend()))
                        sends.add((SessionSend) projected);
                    else return null;
                }
                if(sends.getNumChild()>0){
                    InternalChoice ic = new InternalChoice(sends);
                    if(ic.isWellFormed())
                        return ic;
                }
                if(receives.getNumChild()>0){
                    List<SessionReceive> lis = Session.merge(receives);
                    if(lis.getNumChild()==1) return lis.getChild(0);
                    else{
                        ExternalChoice ext = new ExternalChoice(lis);
                        if(ext.isWellFormed()) return ext;
                    }
                }
            }
            return null;
        }
    finally {
      projectDelegate_String_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected java.util.Set projectDelegating_String_String_visited;
  /**
   * @attribute syn
   * @aspect CommunicationChoiceDelegatingProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\CommunicationChoiceDelegatingProjection.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="CommunicationChoiceDelegatingProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\CommunicationChoiceDelegatingProjection.jadd:3")
  public Session projectDelegating(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegating_String_String_visited == null) projectDelegating_String_String_visited = new java.util.HashSet(4);
    if (projectDelegating_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute CommunicationChoices.projectDelegating(String,String).");
    }
    projectDelegating_String_String_visited.add(_parameters);
    try {
    
            if(getNumCommunications()==1){
                return getCommunications(0).projectDelegating(p, q);
            }else{
                Session s = getCommunications(0).projectDelegating(p,q);
                for(int i = 1; i<getNumCommunications(); i++){
                   Communication c = getCommunications(i);
                   Session s1 = c.projectDelegating(p,q);
                   if(!s1.isSameType(s)) return null;
                }
                return s;
            }
        }
    finally {
      projectDelegating_String_String_visited.remove(_parameters);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9
   * @apilevel internal
   */
  public PrettyPrinter Define_stampante(ASTNode _callerNode, ASTNode _childNode) {
    if (_callerNode == getCommunicationsListNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:13
      int childIndex = _callerNode.getIndexOfChild(_childNode);
      return this.stampante();
    }
    else {
      return getParent().Define_stampante(this, _callerNode);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute stampante
   */
  protected boolean canDefine_stampante(ASTNode _callerNode, ASTNode _childNode) {
    return true;
  }

}
