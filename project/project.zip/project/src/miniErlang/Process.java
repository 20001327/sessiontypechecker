/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\FErlang.ast:15
 * @astdecl Process : ASTNode;
 * @production Process : {@link ASTNode};

 */
public abstract class Process extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:42
   */
  Process getNextProcess(Process p){
        String className = p.getClass().getName();
        if(className.equals(Send.class.getName())){
            Send exp = (Send) p;
            return exp.getNext();
        } else if(className.equals(Register.class.getName())){
            Register exp = (Register) p;
            return exp.getNext();
        }else if(className.equals(Unregister.class.getName())){
           Unregister exp = (Unregister) p;
           return exp.getNext();
        }

        return null;
    }
  /**
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:404
   */
  public void print() {
        printer().append("process");
    }
  /**
   * @declaredat ASTNode:1
   */
  public Process() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:13
   */
  protected int numChildren() {
    return 0;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:17
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    getModuleName_reset();
    getFunctionss_reset();
    getFunType_reset();
    delegating_reset();
    getInfo_String_int_reset();
    printer_reset();
    getDeclarations_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:28
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:33
   */
  public Process clone() throws CloneNotSupportedException {
    Process node = (Process) super.clone();
    return node;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:44
   */
  @Deprecated
  public abstract Process fullCopy();
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:52
   */
  public abstract Process treeCopyNoTransform();
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:60
   */
  public abstract Process treeCopy();
  /**
   * @attribute syn
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:12
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:12")
  public abstract Session type();
/** @apilevel internal */
protected boolean addsIndentationLevel_visited = false;
  /**
   * @attribute syn
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:48
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:44")
  public boolean addsIndentationLevel() {
    if (addsIndentationLevel_visited) {
      throw new RuntimeException("Circular definition of attribute ASTNode.addsIndentationLevel().");
    }
    addsIndentationLevel_visited = true;
    boolean addsIndentationLevel_value = false;
    addsIndentationLevel_visited = false;
    return addsIndentationLevel_value;
  }
  /**
   * @attribute inh
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:14
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:14")
  public String getModuleName() {
    ASTState state = state();
    if (getModuleName_computed) {
      return getModuleName_value;
    }
    if (getModuleName_visited) {
      throw new RuntimeException("Circular definition of attribute Process.getModuleName().");
    }
    getModuleName_visited = true;
    state().enterLazyAttribute();
    getModuleName_value = getParent().Define_getModuleName(this, null);
    getModuleName_computed = true;
    state().leaveLazyAttribute();
    getModuleName_visited = false;
    return getModuleName_value;
  }
/** @apilevel internal */
protected boolean getModuleName_visited = false;
  /** @apilevel internal */
  private void getModuleName_reset() {
    getModuleName_computed = false;
    
    getModuleName_value = null;
    getModuleName_visited = false;
  }
  /** @apilevel internal */
  protected boolean getModuleName_computed = false;

  /** @apilevel internal */
  protected String getModuleName_value;

  /**
   * @attribute inh
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:15
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:15")
  public String getCalledFunName() {
    if (getCalledFunName_visited) {
      throw new RuntimeException("Circular definition of attribute Process.getCalledFunName().");
    }
    getCalledFunName_visited = true;
    String getCalledFunName_value = getParent().Define_getCalledFunName(this, null);
    getCalledFunName_visited = false;
    return getCalledFunName_value;
  }
/** @apilevel internal */
protected boolean getCalledFunName_visited = false;
  /**
   * @attribute inh
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:17
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:17")
  public Process getCalledBody() {
    if (getCalledBody_visited) {
      throw new RuntimeException("Circular definition of attribute Process.getCalledBody().");
    }
    getCalledBody_visited = true;
    Process getCalledBody_value = getParent().Define_getCalledBody(this, null);
    getCalledBody_visited = false;
    return getCalledBody_value;
  }
/** @apilevel internal */
protected boolean getCalledBody_visited = false;
  /**
   * @attribute inh
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:18
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:18")
  public List<Function> getFunctionss() {
    ASTState state = state();
    if (getFunctionss_computed) {
      return getFunctionss_value;
    }
    if (getFunctionss_visited) {
      throw new RuntimeException("Circular definition of attribute Process.getFunctionss().");
    }
    getFunctionss_visited = true;
    state().enterLazyAttribute();
    getFunctionss_value = getParent().Define_getFunctionss(this, null);
    getFunctionss_computed = true;
    state().leaveLazyAttribute();
    getFunctionss_visited = false;
    return getFunctionss_value;
  }
/** @apilevel internal */
protected boolean getFunctionss_visited = false;
  /** @apilevel internal */
  private void getFunctionss_reset() {
    getFunctionss_computed = false;
    
    getFunctionss_value = null;
    getFunctionss_visited = false;
  }
  /** @apilevel internal */
  protected boolean getFunctionss_computed = false;

  /** @apilevel internal */
  protected List<Function> getFunctionss_value;

  /**
   * @attribute inh
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:19
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:19")
  public FunType getFunType() {
    ASTState state = state();
    if (getFunType_computed) {
      return getFunType_value;
    }
    if (getFunType_visited) {
      throw new RuntimeException("Circular definition of attribute Process.getFunType().");
    }
    getFunType_visited = true;
    state().enterLazyAttribute();
    getFunType_value = getParent().Define_getFunType(this, null);
    getFunType_computed = true;
    state().leaveLazyAttribute();
    getFunType_visited = false;
    return getFunType_value;
  }
/** @apilevel internal */
protected boolean getFunType_visited = false;
  /** @apilevel internal */
  private void getFunType_reset() {
    getFunType_computed = false;
    
    getFunType_value = null;
    getFunType_visited = false;
  }
  /** @apilevel internal */
  protected boolean getFunType_computed = false;

  /** @apilevel internal */
  protected FunType getFunType_value;

  /**
   * @attribute inh
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:21
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:21")
  public Delegating delegating() {
    ASTState state = state();
    if (delegating_computed) {
      return delegating_value;
    }
    if (delegating_visited) {
      throw new RuntimeException("Circular definition of attribute Process.delegating().");
    }
    delegating_visited = true;
    state().enterLazyAttribute();
    delegating_value = getParent().Define_delegating(this, null);
    delegating_computed = true;
    state().leaveLazyAttribute();
    delegating_visited = false;
    return delegating_value;
  }
/** @apilevel internal */
protected boolean delegating_visited = false;
  /** @apilevel internal */
  private void delegating_reset() {
    delegating_computed = false;
    
    delegating_value = null;
    delegating_visited = false;
  }
  /** @apilevel internal */
  protected boolean delegating_computed = false;

  /** @apilevel internal */
  protected Delegating delegating_value;

  /**
   * @attribute inh
   * @aspect SessionTypesInformationUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:4
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="SessionTypesInformationUtility", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:4")
  public Session getInfo(String label, int index) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(label);
    _parameters.add(index);
    if (getInfo_String_int_visited == null) getInfo_String_int_visited = new java.util.HashSet(4);
    if (getInfo_String_int_values == null) getInfo_String_int_values = new java.util.HashMap(4);
    ASTState state = state();
    if (getInfo_String_int_values.containsKey(_parameters)) {
      return (Session) getInfo_String_int_values.get(_parameters);
    }
    if (getInfo_String_int_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Process.getInfo(String,int).");
    }
    getInfo_String_int_visited.add(_parameters);
    state().enterLazyAttribute();
    Session getInfo_String_int_value = getParent().Define_getInfo(this, null, label, index);
    getInfo_String_int_values.put(_parameters, getInfo_String_int_value);
    state().leaveLazyAttribute();
    getInfo_String_int_visited.remove(_parameters);
    return getInfo_String_int_value;
  }
/** @apilevel internal */
protected java.util.Set getInfo_String_int_visited;
  /** @apilevel internal */
  private void getInfo_String_int_reset() {
    getInfo_String_int_values = null;
    getInfo_String_int_visited = null;
  }
  /** @apilevel internal */
  protected java.util.Map getInfo_String_int_values;

  /**
   * @attribute inh
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:62
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:62")
  public PrettyPrinter printer() {
    ASTState state = state();
    if (printer_computed) {
      return printer_value;
    }
    if (printer_visited) {
      throw new RuntimeException("Circular definition of attribute Process.printer().");
    }
    printer_visited = true;
    state().enterLazyAttribute();
    printer_value = getParent().Define_printer(this, null);
    printer_computed = true;
    state().leaveLazyAttribute();
    printer_visited = false;
    return printer_value;
  }
/** @apilevel internal */
protected boolean printer_visited = false;
  /** @apilevel internal */
  private void printer_reset() {
    printer_computed = false;
    
    printer_value = null;
    printer_visited = false;
  }
  /** @apilevel internal */
  protected boolean printer_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter printer_value;

  /**
   * @attribute inh
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:55
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="NameAnalisys", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:55")
  public ArrayList<VarDeclaration> getDeclarations() {
    ASTState state = state();
    if (getDeclarations_computed) {
      return getDeclarations_value;
    }
    if (getDeclarations_visited) {
      throw new RuntimeException("Circular definition of attribute Process.getDeclarations().");
    }
    getDeclarations_visited = true;
    state().enterLazyAttribute();
    getDeclarations_value = getParent().Define_getDeclarations(this, null);
    getDeclarations_computed = true;
    state().leaveLazyAttribute();
    getDeclarations_visited = false;
    return getDeclarations_value;
  }
/** @apilevel internal */
protected boolean getDeclarations_visited = false;
  /** @apilevel internal */
  private void getDeclarations_reset() {
    getDeclarations_computed = false;
    
    getDeclarations_value = null;
    getDeclarations_visited = false;
  }
  /** @apilevel internal */
  protected boolean getDeclarations_computed = false;

  /** @apilevel internal */
  protected ArrayList<VarDeclaration> getDeclarations_value;


}
