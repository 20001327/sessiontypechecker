/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\GlobalTypes.ast:1
 * @astdecl GProg : Goal ::= Global:Global;
 * @production GProg : {@link Goal} ::= <span class="component">Global:{@link Global}</span>;

 */
public class GProg extends Goal implements Cloneable {
  /**
   * @aspect ActorDiscover
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\ActorDiscover.jrag:7
   */
  public static void addAbsent(String actor, ArrayList<String> actors){
        if(!actors.contains(actor)){
            actors.add(actor);
        }
    }
  /**
   * @declaredat ASTNode:1
   */
  public GProg() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[1];
  }
  /**
   * @declaredat ASTNode:13
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Global"},
    type = {"Global"},
    kind = {"Child"}
  )
  public GProg(Global p0) {
    setChild(p0, 0);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:22
   */
  protected int numChildren() {
    return 1;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:26
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    stampante_reset();
    getActors_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:32
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:37
   */
  public GProg clone() throws CloneNotSupportedException {
    GProg node = (GProg) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:42
   */
  public GProg copy() {
    try {
      GProg node = (GProg) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:61
   */
  @Deprecated
  public GProg fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:71
   */
  public GProg treeCopyNoTransform() {
    GProg tree = (GProg) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:91
   */
  public GProg treeCopy() {
    GProg tree = (GProg) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the Global child.
   * @param node The new node to replace the Global child.
   * @apilevel high-level
   */
  public GProg setGlobal(Global node) {
    setChild(node, 0);
    return this;
  }
  /**
   * Retrieves the Global child.
   * @return The current node used as the Global child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Global")
  public Global getGlobal() {
    return (Global) getChild(0);
  }
  /**
   * Retrieves the Global child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Global child.
   * @apilevel low-level
   */
  public Global getGlobalNoTransform() {
    return (Global) getChildNoTransform(0);
  }
/** @apilevel internal */
protected boolean stampante_visited = false;
  /** @apilevel internal */
  private void stampante_reset() {
    stampante_computed = false;
    
    stampante_value = null;
    stampante_visited = false;
  }
  /** @apilevel internal */
  protected boolean stampante_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter stampante_value;

  /**
   * @attribute syn
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:4
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="SessionPrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:4")
  public PrettyPrinter stampante() {
    ASTState state = state();
    if (stampante_computed) {
      return stampante_value;
    }
    if (stampante_visited) {
      throw new RuntimeException("Circular definition of attribute GProg.stampante().");
    }
    stampante_visited = true;
    state().enterLazyAttribute();
    stampante_value = stampante_compute();
    stampante_computed = true;
    state().leaveLazyAttribute();
    stampante_visited = false;
    return stampante_value;
  }
  /** @apilevel internal */
  private PrettyPrinter stampante_compute() {
          return new PrettyPrinter();
      }
/** @apilevel internal */
protected boolean getActors_visited = false;
  /** @apilevel internal */
  private void getActors_reset() {
    getActors_computed = false;
    
    getActors_value = null;
    getActors_visited = false;
  }
  /** @apilevel internal */
  protected boolean getActors_computed = false;

  /** @apilevel internal */
  protected ArrayList<String> getActors_value;

  /**
   * @attribute syn
   * @aspect ActorDiscover
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\ActorDiscover.jrag:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ActorDiscover", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\ActorDiscover.jrag:3")
  public ArrayList<String> getActors() {
    ASTState state = state();
    if (getActors_computed) {
      return getActors_value;
    }
    if (getActors_visited) {
      throw new RuntimeException("Circular definition of attribute GProg.getActors().");
    }
    getActors_visited = true;
    state().enterLazyAttribute();
    getActors_value = getActors_compute();
    getActors_computed = true;
    state().leaveLazyAttribute();
    getActors_visited = false;
    return getActors_value;
  }
  /** @apilevel internal */
  private ArrayList<String> getActors_compute() {
          return getGlobal().actors();
      }
/** @apilevel internal */
protected java.util.Set project_String_visited;
  /**
   * @attribute syn
   * @aspect Projection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\Projection.jrag:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="Projection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\Projection.jrag:3")
  public Session project(String actor) {
    Object _parameters = actor;
    if (project_String_visited == null) project_String_visited = new java.util.HashSet(4);
    if (project_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute GProg.project(String).");
    }
    project_String_visited.add(_parameters);
    try {
            return getGlobal().project(actor);
        }
    finally {
      project_String_visited.remove(_parameters);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9
   * @apilevel internal
   */
  public PrettyPrinter Define_stampante(ASTNode _callerNode, ASTNode _childNode) {
    if (_callerNode == getGlobalNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:12
      return this.stampante();
    }
    else {
      return getParent().Define_stampante(this, _callerNode);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute stampante
   */
  protected boolean canDefine_stampante(ASTNode _callerNode, ASTNode _childNode) {
    return true;
  }

}
