/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\GlobalTypes.ast:3
 * @astdecl Global : ASTNode;
 * @production Global : {@link ASTNode};

 */
public abstract class Global extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:8
   */
  public void stampa(){
       stampante().append("global");
    }
  /**
   * @aspect ActorDiscover
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\ActorDiscover.jrag:13
   */
  public ArrayList<String> actors(){
        return new ArrayList<>();
    }
  /**
   * @declaredat ASTNode:1
   */
  public Global() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:13
   */
  protected int numChildren() {
    return 0;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:17
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    project_String_reset();
    projectDelegate_String_String_reset();
    projectDelegating_String_String_reset();
    stampante_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:25
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:30
   */
  public Global clone() throws CloneNotSupportedException {
    Global node = (Global) super.clone();
    return node;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:41
   */
  @Deprecated
  public abstract Global fullCopy();
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:49
   */
  public abstract Global treeCopyNoTransform();
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:57
   */
  public abstract Global treeCopy();
/** @apilevel internal */
protected java.util.Set project_String_visited;
  /** @apilevel internal */
  private void project_String_reset() {
    project_String_values = null;
    project_String_visited = null;
  }
  /** @apilevel internal */
  protected java.util.Map project_String_values;

  /**
   * @attribute syn
   * @aspect Projection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\Projection.jrag:7
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="Projection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\Projection.jrag:7")
  public Session project(String actor) {
    Object _parameters = actor;
    if (project_String_visited == null) project_String_visited = new java.util.HashSet(4);
    if (project_String_values == null) project_String_values = new java.util.HashMap(4);
    ASTState state = state();
    if (project_String_values.containsKey(_parameters)) {
      return (Session) project_String_values.get(_parameters);
    }
    if (project_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Global.project(String).");
    }
    project_String_visited.add(_parameters);
    state().enterLazyAttribute();
    Session project_String_value = project_compute(actor);
    project_String_values.put(_parameters, project_String_value);
    state().leaveLazyAttribute();
    project_String_visited.remove(_parameters);
    return project_String_value;
  }
  /** @apilevel internal */
  private Session project_compute(String actor) {
          return null;
      }
/** @apilevel internal */
protected java.util.Set projectDelegate_String_String_visited;
  /** @apilevel internal */
  private void projectDelegate_String_String_reset() {
    projectDelegate_String_String_values = null;
    projectDelegate_String_String_visited = null;
  }
  /** @apilevel internal */
  protected java.util.Map projectDelegate_String_String_values;

  /**
   * @attribute syn
   * @aspect ProjectDelegate
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\ProjectDelegate.jrag:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ProjectDelegate", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\ProjectDelegate.jrag:3")
  public Session projectDelegate(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegate_String_String_visited == null) projectDelegate_String_String_visited = new java.util.HashSet(4);
    if (projectDelegate_String_String_values == null) projectDelegate_String_String_values = new java.util.HashMap(4);
    ASTState state = state();
    if (projectDelegate_String_String_values.containsKey(_parameters)) {
      return (Session) projectDelegate_String_String_values.get(_parameters);
    }
    if (projectDelegate_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Global.projectDelegate(String,String).");
    }
    projectDelegate_String_String_visited.add(_parameters);
    state().enterLazyAttribute();
    Session projectDelegate_String_String_value = projectDelegate_compute(p, q);
    projectDelegate_String_String_values.put(_parameters, projectDelegate_String_String_value);
    state().leaveLazyAttribute();
    projectDelegate_String_String_visited.remove(_parameters);
    return projectDelegate_String_String_value;
  }
  /** @apilevel internal */
  private Session projectDelegate_compute(String p, String q) {
          return null;
      }
/** @apilevel internal */
protected java.util.Set projectDelegating_String_String_visited;
  /** @apilevel internal */
  private void projectDelegating_String_String_reset() {
    projectDelegating_String_String_values = null;
    projectDelegating_String_String_visited = null;
  }
  /** @apilevel internal */
  protected java.util.Map projectDelegating_String_String_values;

  /**
   * @attribute syn
   * @aspect ProjectDelegating
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\ProjectDelegating.jrag:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ProjectDelegating", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\ProjectDelegating.jrag:3")
  public Session projectDelegating(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegating_String_String_visited == null) projectDelegating_String_String_visited = new java.util.HashSet(4);
    if (projectDelegating_String_String_values == null) projectDelegating_String_String_values = new java.util.HashMap(4);
    ASTState state = state();
    if (projectDelegating_String_String_values.containsKey(_parameters)) {
      return (Session) projectDelegating_String_String_values.get(_parameters);
    }
    if (projectDelegating_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Global.projectDelegating(String,String).");
    }
    projectDelegating_String_String_visited.add(_parameters);
    state().enterLazyAttribute();
    Session projectDelegating_String_String_value = projectDelegating_compute(p, q);
    projectDelegating_String_String_values.put(_parameters, projectDelegating_String_String_value);
    state().leaveLazyAttribute();
    projectDelegating_String_String_visited.remove(_parameters);
    return projectDelegating_String_String_value;
  }
  /** @apilevel internal */
  private Session projectDelegating_compute(String p, String q) {
          return null;
      }
  /**
   * @attribute inh
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:17
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="SessionPrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:17")
  public PrettyPrinter stampante() {
    ASTState state = state();
    if (stampante_computed) {
      return stampante_value;
    }
    if (stampante_visited) {
      throw new RuntimeException("Circular definition of attribute Global.stampante().");
    }
    stampante_visited = true;
    state().enterLazyAttribute();
    stampante_value = getParent().Define_stampante(this, null);
    stampante_computed = true;
    state().leaveLazyAttribute();
    stampante_visited = false;
    return stampante_value;
  }
/** @apilevel internal */
protected boolean stampante_visited = false;
  /** @apilevel internal */
  private void stampante_reset() {
    stampante_computed = false;
    
    stampante_value = null;
    stampante_visited = false;
  }
  /** @apilevel internal */
  protected boolean stampante_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter stampante_value;


}
