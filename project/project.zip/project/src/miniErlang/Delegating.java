package miniErlang;

import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast class
 * @aspect ProcessTypes
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:58
 */
public class Delegating extends java.lang.Object {
  /**
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:60
   */
  

        Atom name;
  /**
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:61
   */
  
        Atom delegateName;
  /**
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:63
   */
  

        public void setName(Atom del){
            name = del;
        }
  /**
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:67
   */
  

        public Atom getName(){
            return name;
        }
  /**
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:71
   */
  

        public void setDelegateName(Atom del){
            delegateName = del;
        }
  /**
   * @aspect ProcessTypes
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:75
   */
  

        public Atom getDelegateName(){
            return delegateName;
        }

}
