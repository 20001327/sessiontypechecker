/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\GlobalTypes.ast:13
 * @astdecl Communication : ASTNode ::= Message:CommunicationChoice Next:Global;
 * @production Communication : {@link ASTNode} ::= <span class="component">Message:{@link CommunicationChoice}</span> <span class="component">Next:{@link Global}</span>;

 */
public class Communication extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:21
   */
  public void stampa(){
        getMessage().stampa();
        stampante().append(".");
        getNext().stampa();
    }
  /**
   * @declaredat ASTNode:1
   */
  public Communication() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[2];
  }
  /**
   * @declaredat ASTNode:13
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Message", "Next"},
    type = {"CommunicationChoice", "Global"},
    kind = {"Child", "Child"}
  )
  public Communication(CommunicationChoice p0, Global p1) {
    setChild(p0, 0);
    setChild(p1, 1);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:23
   */
  protected int numChildren() {
    return 2;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:27
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    stampante_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:32
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:37
   */
  public Communication clone() throws CloneNotSupportedException {
    Communication node = (Communication) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:42
   */
  public Communication copy() {
    try {
      Communication node = (Communication) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:61
   */
  @Deprecated
  public Communication fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:71
   */
  public Communication treeCopyNoTransform() {
    Communication tree = (Communication) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:91
   */
  public Communication treeCopy() {
    Communication tree = (Communication) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the Message child.
   * @param node The new node to replace the Message child.
   * @apilevel high-level
   */
  public Communication setMessage(CommunicationChoice node) {
    setChild(node, 0);
    return this;
  }
  /**
   * Retrieves the Message child.
   * @return The current node used as the Message child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Message")
  public CommunicationChoice getMessage() {
    return (CommunicationChoice) getChild(0);
  }
  /**
   * Retrieves the Message child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Message child.
   * @apilevel low-level
   */
  public CommunicationChoice getMessageNoTransform() {
    return (CommunicationChoice) getChildNoTransform(0);
  }
  /**
   * Replaces the Next child.
   * @param node The new node to replace the Next child.
   * @apilevel high-level
   */
  public Communication setNext(Global node) {
    setChild(node, 1);
    return this;
  }
  /**
   * Retrieves the Next child.
   * @return The current node used as the Next child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Next")
  public Global getNext() {
    return (Global) getChild(1);
  }
  /**
   * Retrieves the Next child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Next child.
   * @apilevel low-level
   */
  public Global getNextNoTransform() {
    return (Global) getChildNoTransform(1);
  }
/** @apilevel internal */
protected java.util.Set project_String_visited;
  /**
   * @attribute syn
   * @aspect CommunicationProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\CommunicationProjection.jadd:2
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="CommunicationProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\CommunicationProjection.jadd:2")
  public Session project(String actor) {
    Object _parameters = actor;
    if (project_String_visited == null) project_String_visited = new java.util.HashSet(4);
    if (project_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Communication.project(String).");
    }
    project_String_visited.add(_parameters);
    try {
            if(actor.equals(getMessage().getSender())){
                if(getMessage().getClass().getName().equals(Connecting.class.getName())){
                  return new ConnectingSend(new Atom(getMessage().getRecipient()),
                                       new Atom(getMessage().getLabel()),
                                       getMessage().getTypess(), getNext().project(actor));
                }else{
                  return new SessionSend(new Atom(getMessage().getRecipient()),
                                        new Atom(getMessage().getLabel()),
                                        getMessage().getTypess(), getNext().project(actor));
                }
            }else if(actor.equals(getMessage().getRecipient())){
                if(getMessage().getClass().getName().equals(Connecting.class.getName())){
                    return new ConnectingReceive(new Atom(getMessage().getSender()),
                                              new Atom(getMessage().getLabel()),
                                              getMessage().getTypess(),getNext().project(actor));
                } else{
                    return new SessionReceive(new Atom(getMessage().getSender()),
                                                new Atom(getMessage().getLabel()),
                                                getMessage().getTypess(),getNext().project(actor));
                }
            }
    
           return getNext().project(actor);
    
        }
    finally {
      project_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected java.util.Set projectDelegate_String_String_visited;
  /**
   * @attribute syn
   * @aspect CommunicationDelegateProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\CommunicationDelegateProjection.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="CommunicationDelegateProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\CommunicationDelegateProjection.jadd:3")
  public Session projectDelegate(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegate_String_String_visited == null) projectDelegate_String_String_visited = new java.util.HashSet(4);
    if (projectDelegate_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Communication.projectDelegate(String,String).");
    }
    projectDelegate_String_String_visited.add(_parameters);
    try {
            if(p.equals(getMessage().getSender()) && !q.equals(getMessage().getRecipient())){
                if(getMessage().getClass().getName().equals(Connecting.class.getName())){
                  return new ConnectingSend(new Atom(getMessage().getRecipient()),
                                               new Atom(getMessage().getLabel()),
                                               getMessage().getTypess(), getNext().projectDelegate(p,q));
                }else{
                  return new SessionSend(new Atom(getMessage().getRecipient()),
                                        new Atom(getMessage().getLabel()),
                                        getMessage().getTypess(), getNext().projectDelegate(p, q));
                }
            }else if(p.equals(getMessage().getRecipient()) && !q.equals(getMessage().getSender())){
                 if(getMessage().getClass().getName().equals(Connecting.class.getName())){
                    return new ConnectingReceive(new Atom(getMessage().getSender()),
                                      new Atom(getMessage().getLabel()),
                                      getMessage().getTypess(),getNext().projectDelegate(p,q));
                 } else{
                    return new SessionReceive(new Atom(getMessage().getSender()),
                                    new Atom(getMessage().getLabel()),
                                    getMessage().getTypess(),getNext().projectDelegate(p,q));
                }
            }else if(!q.equals(getMessage().getSender()) && !q.equals(getMessage().getSender()) &&
                !p.equals(getMessage().getRecipient()) && !p.equals(getMessage().getSender())){
                return getNext().projectDelegate(p,q);
            }
    
            return null;
    
        }
    finally {
      projectDelegate_String_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected java.util.Set projectDelegating_String_String_visited;
  /**
   * @attribute syn
   * @aspect CommunicationDelegatingProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\CommunicationDelegatingProjection.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="CommunicationDelegatingProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\CommunicationDelegatingProjection.jadd:3")
  public Session projectDelegating(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegating_String_String_visited == null) projectDelegating_String_String_visited = new java.util.HashSet(4);
    if (projectDelegating_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Communication.projectDelegating(String,String).");
    }
    projectDelegating_String_String_visited.add(_parameters);
    try {
            if(!q.equals(getMessage().getRecipient()) && !q.equals(getMessage().getSender())){
                return getNext().projectDelegating(p,q);
            }
    
            return null;
    
        }
    finally {
      projectDelegating_String_String_visited.remove(_parameters);
    }
  }
  /**
   * @attribute inh
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:14
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="SessionPrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:14")
  public PrettyPrinter stampante() {
    ASTState state = state();
    if (stampante_computed) {
      return stampante_value;
    }
    if (stampante_visited) {
      throw new RuntimeException("Circular definition of attribute Communication.stampante().");
    }
    stampante_visited = true;
    state().enterLazyAttribute();
    stampante_value = getParent().Define_stampante(this, null);
    stampante_computed = true;
    state().leaveLazyAttribute();
    stampante_visited = false;
    return stampante_value;
  }
/** @apilevel internal */
protected boolean stampante_visited = false;
  /** @apilevel internal */
  private void stampante_reset() {
    stampante_computed = false;
    
    stampante_value = null;
    stampante_visited = false;
  }
  /** @apilevel internal */
  protected boolean stampante_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter stampante_value;

  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9
   * @apilevel internal
   */
  public PrettyPrinter Define_stampante(ASTNode _callerNode, ASTNode _childNode) {
    if (_callerNode == getMessageNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:15
      return this.stampante();
    }
    else {
      return getParent().Define_stampante(this, _callerNode);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute stampante
   */
  protected boolean canDefine_stampante(ASTNode _callerNode, ASTNode _childNode) {
    return true;
  }

}
