/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\GlobalTypes.ast:10
 * @astdecl Terminal : Global;
 * @production Terminal : {@link Global};

 */
public class Terminal extends Global implements Cloneable {
  /**
   * @declaredat ASTNode:1
   */
  public Terminal() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:13
   */
  protected int numChildren() {
    return 0;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:17
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:22
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:27
   */
  public Terminal clone() throws CloneNotSupportedException {
    Terminal node = (Terminal) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:32
   */
  public Terminal copy() {
    try {
      Terminal node = (Terminal) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:51
   */
  @Deprecated
  public Terminal fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:61
   */
  public Terminal treeCopyNoTransform() {
    Terminal tree = (Terminal) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:81
   */
  public Terminal treeCopy() {
    Terminal tree = (Terminal) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
/** @apilevel internal */
protected java.util.Set project_String_visited;
  /**
   * @attribute syn
   * @aspect Projection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\Projection.jrag:11
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="Projection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\Projection.jrag:11")
  public Session project(String actor) {
    Object _parameters = actor;
    if (project_String_visited == null) project_String_visited = new java.util.HashSet(4);
    if (project_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Terminal.project(String).");
    }
    project_String_visited.add(_parameters);
    try {
            return new End();
        }
    finally {
      project_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected java.util.Set projectDelegate_String_String_visited;
  /**
   * @attribute syn
   * @aspect ProjectDelegate
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\ProjectDelegate.jrag:6
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ProjectDelegate", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\ProjectDelegate.jrag:6")
  public Session projectDelegate(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegate_String_String_visited == null) projectDelegate_String_String_visited = new java.util.HashSet(4);
    if (projectDelegate_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Terminal.projectDelegate(String,String).");
    }
    projectDelegate_String_String_visited.add(_parameters);
    try {
            return null;
        }
    finally {
      projectDelegate_String_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected java.util.Set projectDelegating_String_String_visited;
  /**
   * @attribute syn
   * @aspect ProjectDelegating
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\ProjectDelegating.jrag:7
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ProjectDelegating", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\ProjectDelegating.jrag:7")
  public Session projectDelegating(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegating_String_String_visited == null) projectDelegating_String_String_visited = new java.util.HashSet(4);
    if (projectDelegating_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute Terminal.projectDelegating(String,String).");
    }
    projectDelegating_String_String_visited.add(_parameters);
    try {
            return null;
        }
    finally {
      projectDelegating_String_String_visited.remove(_parameters);
    }
  }

}
