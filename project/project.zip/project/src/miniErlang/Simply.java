/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\GlobalTypes.ast:16
 * @astdecl Simply : CommunicationChoice ::= <Sender:String> <Recipient:String> <Label:String> Types:LiteralType*;
 * @production Simply : {@link CommunicationChoice};

 */
public class Simply extends CommunicationChoice implements Cloneable {
  /**
   * @declaredat ASTNode:1
   */
  public Simply() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[1];
    setChild(new List(), 0);
  }
  /**
   * @declaredat ASTNode:14
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Sender", "Recipient", "Label", "Types"},
    type = {"String", "String", "String", "List<LiteralType>"},
    kind = {"Token", "Token", "Token", "List"}
  )
  public Simply(String p0, String p1, String p2, List<LiteralType> p3) {
    setSender(p0);
    setRecipient(p1);
    setLabel(p2);
    setChild(p3, 0);
  }
  /**
   * @declaredat ASTNode:25
   */
  public Simply(beaver.Symbol p0, beaver.Symbol p1, beaver.Symbol p2, List<LiteralType> p3) {
    setSender(p0);
    setRecipient(p1);
    setLabel(p2);
    setChild(p3, 0);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:32
   */
  protected int numChildren() {
    return 1;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:36
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:41
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:46
   */
  public Simply clone() throws CloneNotSupportedException {
    Simply node = (Simply) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:51
   */
  public Simply copy() {
    try {
      Simply node = (Simply) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:70
   */
  @Deprecated
  public Simply fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:80
   */
  public Simply treeCopyNoTransform() {
    Simply tree = (Simply) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:100
   */
  public Simply treeCopy() {
    Simply tree = (Simply) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the lexeme Sender.
   * @param value The new value for the lexeme Sender.
   * @apilevel high-level
   */
  public Simply setSender(String value) {
    tokenString_Sender = value;
    return this;
  }
  /**
   * JastAdd-internal setter for lexeme Sender using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme Sender
   * @apilevel internal
   */
  public Simply setSender(beaver.Symbol symbol) {
    if (symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setSender is only valid for String lexemes");
    tokenString_Sender = (String)symbol.value;
    Senderstart = symbol.getStart();
    Senderend = symbol.getEnd();
    return this;
  }
  /**
   * Retrieves the value for the lexeme Sender.
   * @return The value for the lexeme Sender.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="Sender")
  public String getSender() {
    return tokenString_Sender != null ? tokenString_Sender : "";
  }
  /**
   * Replaces the lexeme Recipient.
   * @param value The new value for the lexeme Recipient.
   * @apilevel high-level
   */
  public Simply setRecipient(String value) {
    tokenString_Recipient = value;
    return this;
  }
  /**
   * JastAdd-internal setter for lexeme Recipient using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme Recipient
   * @apilevel internal
   */
  public Simply setRecipient(beaver.Symbol symbol) {
    if (symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setRecipient is only valid for String lexemes");
    tokenString_Recipient = (String)symbol.value;
    Recipientstart = symbol.getStart();
    Recipientend = symbol.getEnd();
    return this;
  }
  /**
   * Retrieves the value for the lexeme Recipient.
   * @return The value for the lexeme Recipient.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="Recipient")
  public String getRecipient() {
    return tokenString_Recipient != null ? tokenString_Recipient : "";
  }
  /**
   * Replaces the lexeme Label.
   * @param value The new value for the lexeme Label.
   * @apilevel high-level
   */
  public Simply setLabel(String value) {
    tokenString_Label = value;
    return this;
  }
  /**
   * JastAdd-internal setter for lexeme Label using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme Label
   * @apilevel internal
   */
  public Simply setLabel(beaver.Symbol symbol) {
    if (symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setLabel is only valid for String lexemes");
    tokenString_Label = (String)symbol.value;
    Labelstart = symbol.getStart();
    Labelend = symbol.getEnd();
    return this;
  }
  /**
   * Retrieves the value for the lexeme Label.
   * @return The value for the lexeme Label.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="Label")
  public String getLabel() {
    return tokenString_Label != null ? tokenString_Label : "";
  }
  /**
   * Replaces the Types list.
   * @param list The new list node to be used as the Types list.
   * @apilevel high-level
   */
  public Simply setTypesList(List<LiteralType> list) {
    setChild(list, 0);
    return this;
  }
  /**
   * Retrieves the number of children in the Types list.
   * @return Number of children in the Types list.
   * @apilevel high-level
   */
  public int getNumTypes() {
    return getTypesList().getNumChild();
  }
  /**
   * Retrieves the number of children in the Types list.
   * Calling this method will not trigger rewrites.
   * @return Number of children in the Types list.
   * @apilevel low-level
   */
  public int getNumTypesNoTransform() {
    return getTypesListNoTransform().getNumChildNoTransform();
  }
  /**
   * Retrieves the element at index {@code i} in the Types list.
   * @param i Index of the element to return.
   * @return The element at position {@code i} in the Types list.
   * @apilevel high-level
   */
  public LiteralType getTypes(int i) {
    return (LiteralType) getTypesList().getChild(i);
  }
  /**
   * Check whether the Types list has any children.
   * @return {@code true} if it has at least one child, {@code false} otherwise.
   * @apilevel high-level
   */
  public boolean hasTypes() {
    return getTypesList().getNumChild() != 0;
  }
  /**
   * Append an element to the Types list.
   * @param node The element to append to the Types list.
   * @apilevel high-level
   */
  public Simply addTypes(LiteralType node) {
    List<LiteralType> list = (parent == null) ? getTypesListNoTransform() : getTypesList();
    list.addChild(node);
    return this;
  }
  /** @apilevel low-level 
   */
  public Simply addTypesNoTransform(LiteralType node) {
    List<LiteralType> list = getTypesListNoTransform();
    list.addChild(node);
    return this;
  }
  /**
   * Replaces the Types list element at index {@code i} with the new node {@code node}.
   * @param node The new node to replace the old list element.
   * @param i The list index of the node to be replaced.
   * @apilevel high-level
   */
  public Simply setTypes(LiteralType node, int i) {
    List<LiteralType> list = getTypesList();
    list.setChild(node, i);
    return this;
  }
  /**
   * Retrieves the Types list.
   * @return The node representing the Types list.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.ListChild(name="Types")
  public List<LiteralType> getTypesList() {
    List<LiteralType> list = (List<LiteralType>) getChild(0);
    return list;
  }
  /**
   * Retrieves the Types list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Types list.
   * @apilevel low-level
   */
  public List<LiteralType> getTypesListNoTransform() {
    return (List<LiteralType>) getChildNoTransform(0);
  }
  /**
   * @return the element at index {@code i} in the Types list without
   * triggering rewrites.
   */
  public LiteralType getTypesNoTransform(int i) {
    return (LiteralType) getTypesListNoTransform().getChildNoTransform(i);
  }
  /**
   * Retrieves the Types list.
   * @return The node representing the Types list.
   * @apilevel high-level
   */
  public List<LiteralType> getTypess() {
    return getTypesList();
  }
  /**
   * Retrieves the Types list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Types list.
   * @apilevel low-level
   */
  public List<LiteralType> getTypessNoTransform() {
    return getTypesListNoTransform();
  }

}
