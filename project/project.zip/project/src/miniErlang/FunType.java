/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\Session.ast:27
 * @astdecl FunType : Session ::= <FunName:String> Arguments:LiteralType* SessionType:Session;
 * @production FunType : {@link Session} ::= <span class="component">&lt;FunName:{@link String}&gt;</span> <span class="component">Arguments:{@link LiteralType}*</span> <span class="component">SessionType:{@link Session}</span>;

 */
public class FunType extends Session implements Cloneable {
  /**
   * @aspect EndsWithUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\EndsWithUtility.jrag:86
   */
  public boolean endsWith(RecVar var) {
           return getSessionType().endsWith(var);
    }
  /**
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:120
   */
  public void print(){
       printer().append("\n");
       printer().append("-type " + getFunName() + "(");
       for (int i=0; i<getNumArguments(); i++) {
           LiteralType var = getArguments(i);
           printer().append(var.getClass().getName());
           if(i<getNumArguments()-1){
               printer().append(",");
           }
       }
       printer().append(") :: '");
       getSessionType().print();
       printer().append("'");
    }
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:26
   */
  public void stampa(){
       stampante().append("\n");
       stampante().append("-type " + getFunName() + "(");
       for (int i=0; i<getNumArguments(); i++) {
           LiteralType var = getArguments(i);
           stampante().append(var.getClass().getName());
           if(i<getNumArguments()-1){
               stampante().append(",");
           }
       }
       stampante().append(") :: '");
       getSessionType().stampa();
       stampante().append("'");
    }
  /**
   * @aspect SessionComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\SessionComparison.jrag:3
   */
  public boolean compareWith(FunType type) {
        boolean name = this.getFunName().equals(type.getFunName());
        boolean arguments = Program.checkLists(getArgumentss(),type.getArgumentss());
        boolean sessions = getSessionType().subtypeOf(type.getSessionType());
        return name && arguments && sessions;
    }
  /**
   * @aspect SessionComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\SessionComparison.jrag:12
   */
  public boolean subtypeOf(Object other){
        return false;
    }
  /**
   * @aspect TypesComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\TypesComparison.jrag:83
   */
  public boolean isSubtypeOf(Session t) {
            return t instanceof FunType;
    }
  /**
   * @declaredat ASTNode:1
   */
  public FunType() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[2];
    setChild(new List(), 0);
  }
  /**
   * @declaredat ASTNode:14
   */
  @ASTNodeAnnotation.Constructor(
    name = {"FunName", "Arguments", "SessionType"},
    type = {"String", "List<LiteralType>", "Session"},
    kind = {"Token", "List", "Child"}
  )
  public FunType(String p0, List<LiteralType> p1, Session p2) {
    setFunName(p0);
    setChild(p1, 0);
    setChild(p2, 1);
  }
  /**
   * @declaredat ASTNode:24
   */
  public FunType(beaver.Symbol p0, List<LiteralType> p1, Session p2) {
    setFunName(p0);
    setChild(p1, 0);
    setChild(p2, 1);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:30
   */
  protected int numChildren() {
    return 2;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:34
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    stampante_reset();
    printer_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:40
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:45
   */
  public FunType clone() throws CloneNotSupportedException {
    FunType node = (FunType) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:50
   */
  public FunType copy() {
    try {
      FunType node = (FunType) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:69
   */
  @Deprecated
  public FunType fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:79
   */
  public FunType treeCopyNoTransform() {
    FunType tree = (FunType) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:99
   */
  public FunType treeCopy() {
    FunType tree = (FunType) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the lexeme FunName.
   * @param value The new value for the lexeme FunName.
   * @apilevel high-level
   */
  public FunType setFunName(String value) {
    tokenString_FunName = value;
    return this;
  }
  /** @apilevel internal 
   */
  protected String tokenString_FunName;
  /**
   */
  public int FunNamestart;
  /**
   */
  public int FunNameend;
  /**
   * JastAdd-internal setter for lexeme FunName using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme FunName
   * @apilevel internal
   */
  public FunType setFunName(beaver.Symbol symbol) {
    if (symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setFunName is only valid for String lexemes");
    tokenString_FunName = (String)symbol.value;
    FunNamestart = symbol.getStart();
    FunNameend = symbol.getEnd();
    return this;
  }
  /**
   * Retrieves the value for the lexeme FunName.
   * @return The value for the lexeme FunName.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="FunName")
  public String getFunName() {
    return tokenString_FunName != null ? tokenString_FunName : "";
  }
  /**
   * Replaces the Arguments list.
   * @param list The new list node to be used as the Arguments list.
   * @apilevel high-level
   */
  public FunType setArgumentsList(List<LiteralType> list) {
    setChild(list, 0);
    return this;
  }
  /**
   * Retrieves the number of children in the Arguments list.
   * @return Number of children in the Arguments list.
   * @apilevel high-level
   */
  public int getNumArguments() {
    return getArgumentsList().getNumChild();
  }
  /**
   * Retrieves the number of children in the Arguments list.
   * Calling this method will not trigger rewrites.
   * @return Number of children in the Arguments list.
   * @apilevel low-level
   */
  public int getNumArgumentsNoTransform() {
    return getArgumentsListNoTransform().getNumChildNoTransform();
  }
  /**
   * Retrieves the element at index {@code i} in the Arguments list.
   * @param i Index of the element to return.
   * @return The element at position {@code i} in the Arguments list.
   * @apilevel high-level
   */
  public LiteralType getArguments(int i) {
    return (LiteralType) getArgumentsList().getChild(i);
  }
  /**
   * Check whether the Arguments list has any children.
   * @return {@code true} if it has at least one child, {@code false} otherwise.
   * @apilevel high-level
   */
  public boolean hasArguments() {
    return getArgumentsList().getNumChild() != 0;
  }
  /**
   * Append an element to the Arguments list.
   * @param node The element to append to the Arguments list.
   * @apilevel high-level
   */
  public FunType addArguments(LiteralType node) {
    List<LiteralType> list = (parent == null) ? getArgumentsListNoTransform() : getArgumentsList();
    list.addChild(node);
    return this;
  }
  /** @apilevel low-level 
   */
  public FunType addArgumentsNoTransform(LiteralType node) {
    List<LiteralType> list = getArgumentsListNoTransform();
    list.addChild(node);
    return this;
  }
  /**
   * Replaces the Arguments list element at index {@code i} with the new node {@code node}.
   * @param node The new node to replace the old list element.
   * @param i The list index of the node to be replaced.
   * @apilevel high-level
   */
  public FunType setArguments(LiteralType node, int i) {
    List<LiteralType> list = getArgumentsList();
    list.setChild(node, i);
    return this;
  }
  /**
   * Retrieves the Arguments list.
   * @return The node representing the Arguments list.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.ListChild(name="Arguments")
  public List<LiteralType> getArgumentsList() {
    List<LiteralType> list = (List<LiteralType>) getChild(0);
    return list;
  }
  /**
   * Retrieves the Arguments list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Arguments list.
   * @apilevel low-level
   */
  public List<LiteralType> getArgumentsListNoTransform() {
    return (List<LiteralType>) getChildNoTransform(0);
  }
  /**
   * @return the element at index {@code i} in the Arguments list without
   * triggering rewrites.
   */
  public LiteralType getArgumentsNoTransform(int i) {
    return (LiteralType) getArgumentsListNoTransform().getChildNoTransform(i);
  }
  /**
   * Retrieves the Arguments list.
   * @return The node representing the Arguments list.
   * @apilevel high-level
   */
  public List<LiteralType> getArgumentss() {
    return getArgumentsList();
  }
  /**
   * Retrieves the Arguments list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Arguments list.
   * @apilevel low-level
   */
  public List<LiteralType> getArgumentssNoTransform() {
    return getArgumentsListNoTransform();
  }
  /**
   * Replaces the SessionType child.
   * @param node The new node to replace the SessionType child.
   * @apilevel high-level
   */
  public FunType setSessionType(Session node) {
    setChild(node, 1);
    return this;
  }
  /**
   * Retrieves the SessionType child.
   * @return The current node used as the SessionType child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="SessionType")
  public Session getSessionType() {
    return (Session) getChild(1);
  }
  /**
   * Retrieves the SessionType child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the SessionType child.
   * @apilevel low-level
   */
  public Session getSessionTypeNoTransform() {
    return (Session) getChildNoTransform(1);
  }
/** @apilevel internal */
protected boolean stampante_visited = false;
  /** @apilevel internal */
  private void stampante_reset() {
    stampante_computed = false;
    
    stampante_value = null;
    stampante_visited = false;
  }
  /** @apilevel internal */
  protected boolean stampante_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter stampante_value;

  /**
   * @attribute syn
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:4
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="SessionPrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:4")
  public PrettyPrinter stampante() {
    ASTState state = state();
    if (stampante_computed) {
      return stampante_value;
    }
    if (stampante_visited) {
      throw new RuntimeException("Circular definition of attribute FunType.stampante().");
    }
    stampante_visited = true;
    state().enterLazyAttribute();
    stampante_value = stampante_compute();
    stampante_computed = true;
    state().leaveLazyAttribute();
    stampante_visited = false;
    return stampante_value;
  }
  /** @apilevel internal */
  private PrettyPrinter stampante_compute() {
          return new PrettyPrinter();
      }
  /**
   * @attribute inh
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:61
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:61")
  public PrettyPrinter printer() {
    ASTState state = state();
    if (printer_computed) {
      return printer_value;
    }
    if (printer_visited) {
      throw new RuntimeException("Circular definition of attribute FunType.printer().");
    }
    printer_visited = true;
    state().enterLazyAttribute();
    printer_value = getParent().Define_printer(this, null);
    printer_computed = true;
    state().leaveLazyAttribute();
    printer_visited = false;
    return printer_value;
  }
/** @apilevel internal */
protected boolean printer_visited = false;
  /** @apilevel internal */
  private void printer_reset() {
    printer_computed = false;
    
    printer_value = null;
    printer_visited = false;
  }
  /** @apilevel internal */
  protected boolean printer_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter printer_value;

  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9
   * @apilevel internal
   */
  public PrettyPrinter Define_stampante(ASTNode _callerNode, ASTNode _childNode) {
    if (_callerNode == getSessionTypeNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:8
      return this.stampante();
    }
    else if (_callerNode == getArgumentsListNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:7
      int childIndex = _callerNode.getIndexOfChild(_childNode);
      return this.stampante();
    }
    else {
      return getParent().Define_stampante(this, _callerNode);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute stampante
   */
  protected boolean canDefine_stampante(ASTNode _callerNode, ASTNode _childNode) {
    return true;
  }

}
