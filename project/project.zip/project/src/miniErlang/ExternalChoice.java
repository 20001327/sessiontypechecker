/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\Session.ast:6
 * @astdecl ExternalChoice : Session ::= Receives:SessionReceive*;
 * @production ExternalChoice : {@link Session} ::= <span class="component">Receives:{@link SessionReceive}*</span>;

 */
public class ExternalChoice extends Session implements Cloneable {
  /**
   * @aspect EndsWithUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\EndsWithUtility.jrag:21
   */
  public boolean endsWith(RecVar var){
        boolean found = false;
        for (SessionReceive s1: getReceivess()){
            found = found || s1.endsWith(var);
        }

        return found;
    }
  /**
   * @aspect SessionTypesInformationUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:33
   */
  public Session getInfo(String label,int index){
        if(!this.isWellFormed()){
            return null;
        }

        if(getNumReceives()>0){
            for (int i=0; i<getNumReceives(); i++) {
                Session s = getReceives(i).getInfo(label, index);
                if(s!=null){
                    return s;
                }
            }
        }
        return null;
    }
  /**
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:184
   */
  public void print(){
        printer().append("&(");
        if(getNumReceives()>0){
            for (int i=0; i<getNumReceives(); i++) {
                getReceives(i).print();
                if(i<getNumReceives()-1){
                    printer().append(",");
                }
            }
        }
        printer().append(")");
    }
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:107
   */
  public void stampa(){
        stampante().append("&(");
        if(getNumReceives()>0){
            for (int i=0; i<getNumReceives(); i++) {
                getReceives(i).stampa();
                if(i<getNumReceives()-1){
                    stampante().append(",");
                }
            }
        }
        stampante().append(")");
    }
  /**
   * @aspect TypesComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\TypesComparison.jrag:63
   */
  public boolean isSubtypeOf(Session t) {
            return t instanceof ExternalChoice;
    }
  /**
   * @aspect ExternalChoiceSubTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\session\\ExternalChoiceSubtyping.jadd:2
   */
  public boolean subtypeOf(Object other){
        if(Program.sameClass(this, other)){
            ExternalChoice obj = (ExternalChoice) other;
            boolean foundAll = true;
            for (SessionReceive s1: getReceivess()){
              boolean found = false;
              for (SessionReceive s2 : obj.getReceivess()){
                found = found || s1.subtypeOf(s2);
              }
              foundAll = found && foundAll;
            }
            return foundAll;
        }
        return false;
    }
  /**
   * @aspect InternalChoiceValidation
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\validation\\InternalChoiceValidation.jrag:34
   */
  public boolean isPresentInThisMap(Map<String,String> map){
        return false;
    }
  /**
   * @declaredat ASTNode:1
   */
  public ExternalChoice() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[1];
    setChild(new List(), 0);
  }
  /**
   * @declaredat ASTNode:14
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Receives"},
    type = {"List<SessionReceive>"},
    kind = {"List"}
  )
  public ExternalChoice(List<SessionReceive> p0) {
    setChild(p0, 0);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:23
   */
  protected int numChildren() {
    return 1;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:27
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:32
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:37
   */
  public ExternalChoice clone() throws CloneNotSupportedException {
    ExternalChoice node = (ExternalChoice) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:42
   */
  public ExternalChoice copy() {
    try {
      ExternalChoice node = (ExternalChoice) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:61
   */
  @Deprecated
  public ExternalChoice fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:71
   */
  public ExternalChoice treeCopyNoTransform() {
    ExternalChoice tree = (ExternalChoice) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:91
   */
  public ExternalChoice treeCopy() {
    ExternalChoice tree = (ExternalChoice) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the Receives list.
   * @param list The new list node to be used as the Receives list.
   * @apilevel high-level
   */
  public ExternalChoice setReceivesList(List<SessionReceive> list) {
    setChild(list, 0);
    return this;
  }
  /**
   * Retrieves the number of children in the Receives list.
   * @return Number of children in the Receives list.
   * @apilevel high-level
   */
  public int getNumReceives() {
    return getReceivesList().getNumChild();
  }
  /**
   * Retrieves the number of children in the Receives list.
   * Calling this method will not trigger rewrites.
   * @return Number of children in the Receives list.
   * @apilevel low-level
   */
  public int getNumReceivesNoTransform() {
    return getReceivesListNoTransform().getNumChildNoTransform();
  }
  /**
   * Retrieves the element at index {@code i} in the Receives list.
   * @param i Index of the element to return.
   * @return The element at position {@code i} in the Receives list.
   * @apilevel high-level
   */
  public SessionReceive getReceives(int i) {
    return (SessionReceive) getReceivesList().getChild(i);
  }
  /**
   * Check whether the Receives list has any children.
   * @return {@code true} if it has at least one child, {@code false} otherwise.
   * @apilevel high-level
   */
  public boolean hasReceives() {
    return getReceivesList().getNumChild() != 0;
  }
  /**
   * Append an element to the Receives list.
   * @param node The element to append to the Receives list.
   * @apilevel high-level
   */
  public ExternalChoice addReceives(SessionReceive node) {
    List<SessionReceive> list = (parent == null) ? getReceivesListNoTransform() : getReceivesList();
    list.addChild(node);
    return this;
  }
  /** @apilevel low-level 
   */
  public ExternalChoice addReceivesNoTransform(SessionReceive node) {
    List<SessionReceive> list = getReceivesListNoTransform();
    list.addChild(node);
    return this;
  }
  /**
   * Replaces the Receives list element at index {@code i} with the new node {@code node}.
   * @param node The new node to replace the old list element.
   * @param i The list index of the node to be replaced.
   * @apilevel high-level
   */
  public ExternalChoice setReceives(SessionReceive node, int i) {
    List<SessionReceive> list = getReceivesList();
    list.setChild(node, i);
    return this;
  }
  /**
   * Retrieves the Receives list.
   * @return The node representing the Receives list.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.ListChild(name="Receives")
  public List<SessionReceive> getReceivesList() {
    List<SessionReceive> list = (List<SessionReceive>) getChild(0);
    return list;
  }
  /**
   * Retrieves the Receives list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Receives list.
   * @apilevel low-level
   */
  public List<SessionReceive> getReceivesListNoTransform() {
    return (List<SessionReceive>) getChildNoTransform(0);
  }
  /**
   * @return the element at index {@code i} in the Receives list without
   * triggering rewrites.
   */
  public SessionReceive getReceivesNoTransform(int i) {
    return (SessionReceive) getReceivesListNoTransform().getChildNoTransform(i);
  }
  /**
   * Retrieves the Receives list.
   * @return The node representing the Receives list.
   * @apilevel high-level
   */
  public List<SessionReceive> getReceivess() {
    return getReceivesList();
  }
  /**
   * Retrieves the Receives list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Receives list.
   * @apilevel low-level
   */
  public List<SessionReceive> getReceivessNoTransform() {
    return getReceivesListNoTransform();
  }
/** @apilevel internal */
protected boolean isWellFormed_visited = false;
  /**
   * @attribute syn
   * @aspect ExternalChoiceValidation
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\validation\\ExternalChoiceValidation.jadd:2
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ExternalChoiceValidation", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\validation\\ExternalChoiceValidation.jadd:2")
  public boolean isWellFormed() {
    if (isWellFormed_visited) {
      throw new RuntimeException("Circular definition of attribute ExternalChoice.isWellFormed().");
    }
    isWellFormed_visited = true;
    try {
            boolean allSimple = true;
            boolean allConnecting = true;
            Map<String, String> map = new HashMap();
            for(int i = 0; i<getNumReceives();i++){
                allSimple = allSimple && Program.sameClass(getReceives(i),
                                                            SessionReceive.class);
                allConnecting = allConnecting &&
                            (Program.sameClass(getReceives(i),ConnectingReceive.class)
                                  || getReceives(i).isSubtypeOf(new End()));
                if(getReceives(i).isReceivePresentInThisMap(map))
                    return false;
            }
            return allConnecting || allSimple;
        }
    finally {
      isWellFormed_visited = false;
    }
  }

}
