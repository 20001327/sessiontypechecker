/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\Session.ast:25
 * @astdecl AtS : LiteralType ::= <Partecipant:String>;
 * @production AtS : {@link LiteralType} ::= <span class="component">&lt;Partecipant:{@link String}&gt;</span>;

 */
public class AtS extends LiteralType implements Cloneable {
  /**
   * @aspect EndsWithUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\EndsWithUtility.jrag:58
   */
  public boolean endsWith(RecVar var) {
            return false;
    }
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:160
   */
  public void stampa() {
        stampante().append("End");
    }
  /**
   * @aspect TypesComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\TypesComparison.jrag:43
   */
  public boolean isSubtypeOf(Session t) {
            return t instanceof AtS;
    }
  /**
   * @declaredat ASTNode:1
   */
  public AtS() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
  }
  /**
   * @declaredat ASTNode:12
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Partecipant"},
    type = {"String"},
    kind = {"Token"}
  )
  public AtS(String p0) {
    setPartecipant(p0);
  }
  /**
   * @declaredat ASTNode:20
   */
  public AtS(beaver.Symbol p0) {
    setPartecipant(p0);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:24
   */
  protected int numChildren() {
    return 0;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:28
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:33
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:38
   */
  public AtS clone() throws CloneNotSupportedException {
    AtS node = (AtS) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:43
   */
  public AtS copy() {
    try {
      AtS node = (AtS) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:62
   */
  @Deprecated
  public AtS fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:72
   */
  public AtS treeCopyNoTransform() {
    AtS tree = (AtS) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:92
   */
  public AtS treeCopy() {
    AtS tree = (AtS) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the lexeme Partecipant.
   * @param value The new value for the lexeme Partecipant.
   * @apilevel high-level
   */
  public AtS setPartecipant(String value) {
    tokenString_Partecipant = value;
    return this;
  }
  /** @apilevel internal 
   */
  protected String tokenString_Partecipant;
  /**
   */
  public int Partecipantstart;
  /**
   */
  public int Partecipantend;
  /**
   * JastAdd-internal setter for lexeme Partecipant using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme Partecipant
   * @apilevel internal
   */
  public AtS setPartecipant(beaver.Symbol symbol) {
    if (symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setPartecipant is only valid for String lexemes");
    tokenString_Partecipant = (String)symbol.value;
    Partecipantstart = symbol.getStart();
    Partecipantend = symbol.getEnd();
    return this;
  }
  /**
   * Retrieves the value for the lexeme Partecipant.
   * @return The value for the lexeme Partecipant.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="Partecipant")
  public String getPartecipant() {
    return tokenString_Partecipant != null ? tokenString_Partecipant : "";
  }

}
