/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\Session.ast:11
 * @astdecl RecType : Session ::= RecVariable:RecVar Type:Session;
 * @production RecType : {@link Session} ::= <span class="component">RecVariable:{@link RecVar}</span> <span class="component">Type:{@link Session}</span>;

 */
public class RecType extends Session implements Cloneable {
  /**
   * @aspect EndsWithUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\EndsWithUtility.jrag:9
   */
  public boolean endsWith(RecVar var){
        return this.getType().endsWith(var);
    }
  /**
   * @aspect SessionTypesInformationUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:73
   */
  public Session getInfo(String label,int index){
        return getType().getInfo(label, index);
    }
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:14
   */
  public void stampa(){
       stampante().append("rec");
       getRecVariable().stampa();
       stampante().append(".");
       getType().stampa();
    }
  /**
   * @aspect TypesComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\TypesComparison.jrag:19
   */
  public boolean isSubtypeOf(Session t) {
            return t instanceof RecType;
    }
  /**
   * @aspect RecSubtyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\session\\RecSubtyping.jadd:3
   */
  public boolean subtypeOf(Object other){
        if(getType().endsWith(getRecVariable())){
            if(((Session)other).isSubtypeOf(new RecType())){
                RecType oth = (RecType) other;
                return this.getType().subtypeOf(oth.getType());
            }
        }
        return false;
    }
  /**
   * @declaredat ASTNode:1
   */
  public RecType() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[2];
  }
  /**
   * @declaredat ASTNode:13
   */
  @ASTNodeAnnotation.Constructor(
    name = {"RecVariable", "Type"},
    type = {"RecVar", "Session"},
    kind = {"Child", "Child"}
  )
  public RecType(RecVar p0, Session p1) {
    setChild(p0, 0);
    setChild(p1, 1);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:23
   */
  protected int numChildren() {
    return 2;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:27
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:32
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:37
   */
  public RecType clone() throws CloneNotSupportedException {
    RecType node = (RecType) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:42
   */
  public RecType copy() {
    try {
      RecType node = (RecType) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:61
   */
  @Deprecated
  public RecType fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:71
   */
  public RecType treeCopyNoTransform() {
    RecType tree = (RecType) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:91
   */
  public RecType treeCopy() {
    RecType tree = (RecType) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the RecVariable child.
   * @param node The new node to replace the RecVariable child.
   * @apilevel high-level
   */
  public RecType setRecVariable(RecVar node) {
    setChild(node, 0);
    return this;
  }
  /**
   * Retrieves the RecVariable child.
   * @return The current node used as the RecVariable child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="RecVariable")
  public RecVar getRecVariable() {
    return (RecVar) getChild(0);
  }
  /**
   * Retrieves the RecVariable child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the RecVariable child.
   * @apilevel low-level
   */
  public RecVar getRecVariableNoTransform() {
    return (RecVar) getChildNoTransform(0);
  }
  /**
   * Replaces the Type child.
   * @param node The new node to replace the Type child.
   * @apilevel high-level
   */
  public RecType setType(Session node) {
    setChild(node, 1);
    return this;
  }
  /**
   * Retrieves the Type child.
   * @return The current node used as the Type child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Type")
  public Session getType() {
    return (Session) getChild(1);
  }
  /**
   * Retrieves the Type child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Type child.
   * @apilevel low-level
   */
  public Session getTypeNoTransform() {
    return (Session) getChildNoTransform(1);
  }

}
