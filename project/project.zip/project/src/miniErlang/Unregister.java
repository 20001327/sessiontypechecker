/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\FErlang.ast:18
 * @astdecl Unregister : Process ::= Arguments:Expression* Next:Process;
 * @production Unregister : {@link Process} ::= <span class="component">Arguments:{@link Expression}*</span> <span class="component">Next:{@link Process}</span>;

 */
public class Unregister extends Process implements Cloneable {
  /**
   * @aspect Equals
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\Equals.jrag:126
   */
  public boolean equals(Object o){
        if(this.getClass().getName().equals(o.getClass().getName())){
            Unregister other = (Unregister) o;
            return Program.compareExpressions(getArgumentss(),other.getArgumentss(), getDeclarations());
        }
        return false;
    }
  /**
   * @declaredat ASTNode:1
   */
  public Unregister() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[2];
    setChild(new List(), 0);
  }
  /**
   * @declaredat ASTNode:14
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Arguments", "Next"},
    type = {"List<Expression>", "Process"},
    kind = {"List", "Child"}
  )
  public Unregister(List<Expression> p0, Process p1) {
    setChild(p0, 0);
    setChild(p1, 1);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:24
   */
  protected int numChildren() {
    return 2;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:28
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    type_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:33
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:38
   */
  public Unregister clone() throws CloneNotSupportedException {
    Unregister node = (Unregister) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:43
   */
  public Unregister copy() {
    try {
      Unregister node = (Unregister) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:62
   */
  @Deprecated
  public Unregister fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:72
   */
  public Unregister treeCopyNoTransform() {
    Unregister tree = (Unregister) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:92
   */
  public Unregister treeCopy() {
    Unregister tree = (Unregister) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the Arguments list.
   * @param list The new list node to be used as the Arguments list.
   * @apilevel high-level
   */
  public Unregister setArgumentsList(List<Expression> list) {
    setChild(list, 0);
    return this;
  }
  /**
   * Retrieves the number of children in the Arguments list.
   * @return Number of children in the Arguments list.
   * @apilevel high-level
   */
  public int getNumArguments() {
    return getArgumentsList().getNumChild();
  }
  /**
   * Retrieves the number of children in the Arguments list.
   * Calling this method will not trigger rewrites.
   * @return Number of children in the Arguments list.
   * @apilevel low-level
   */
  public int getNumArgumentsNoTransform() {
    return getArgumentsListNoTransform().getNumChildNoTransform();
  }
  /**
   * Retrieves the element at index {@code i} in the Arguments list.
   * @param i Index of the element to return.
   * @return The element at position {@code i} in the Arguments list.
   * @apilevel high-level
   */
  public Expression getArguments(int i) {
    return (Expression) getArgumentsList().getChild(i);
  }
  /**
   * Check whether the Arguments list has any children.
   * @return {@code true} if it has at least one child, {@code false} otherwise.
   * @apilevel high-level
   */
  public boolean hasArguments() {
    return getArgumentsList().getNumChild() != 0;
  }
  /**
   * Append an element to the Arguments list.
   * @param node The element to append to the Arguments list.
   * @apilevel high-level
   */
  public Unregister addArguments(Expression node) {
    List<Expression> list = (parent == null) ? getArgumentsListNoTransform() : getArgumentsList();
    list.addChild(node);
    return this;
  }
  /** @apilevel low-level 
   */
  public Unregister addArgumentsNoTransform(Expression node) {
    List<Expression> list = getArgumentsListNoTransform();
    list.addChild(node);
    return this;
  }
  /**
   * Replaces the Arguments list element at index {@code i} with the new node {@code node}.
   * @param node The new node to replace the old list element.
   * @param i The list index of the node to be replaced.
   * @apilevel high-level
   */
  public Unregister setArguments(Expression node, int i) {
    List<Expression> list = getArgumentsList();
    list.setChild(node, i);
    return this;
  }
  /**
   * Retrieves the Arguments list.
   * @return The node representing the Arguments list.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.ListChild(name="Arguments")
  public List<Expression> getArgumentsList() {
    List<Expression> list = (List<Expression>) getChild(0);
    return list;
  }
  /**
   * Retrieves the Arguments list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Arguments list.
   * @apilevel low-level
   */
  public List<Expression> getArgumentsListNoTransform() {
    return (List<Expression>) getChildNoTransform(0);
  }
  /**
   * @return the element at index {@code i} in the Arguments list without
   * triggering rewrites.
   */
  public Expression getArgumentsNoTransform(int i) {
    return (Expression) getArgumentsListNoTransform().getChildNoTransform(i);
  }
  /**
   * Retrieves the Arguments list.
   * @return The node representing the Arguments list.
   * @apilevel high-level
   */
  public List<Expression> getArgumentss() {
    return getArgumentsList();
  }
  /**
   * Retrieves the Arguments list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Arguments list.
   * @apilevel low-level
   */
  public List<Expression> getArgumentssNoTransform() {
    return getArgumentsListNoTransform();
  }
  /**
   * Replaces the Next child.
   * @param node The new node to replace the Next child.
   * @apilevel high-level
   */
  public Unregister setNext(Process node) {
    setChild(node, 1);
    return this;
  }
  /**
   * Retrieves the Next child.
   * @return The current node used as the Next child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Next")
  public Process getNext() {
    return (Process) getChild(1);
  }
  /**
   * Retrieves the Next child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Next child.
   * @apilevel low-level
   */
  public Process getNextNoTransform() {
    return (Process) getChildNoTransform(1);
  }
/** @apilevel internal */
protected boolean type_visited = false;
  /** @apilevel internal */
  private void type_reset() {
    type_computed = false;
    
    type_value = null;
    type_visited = false;
  }
  /** @apilevel internal */
  protected boolean type_computed = false;

  /** @apilevel internal */
  protected Session type_value;

  /**
   * @attribute syn
   * @aspect UnregisterTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\UnregisterTyping.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ProcessTypes", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\ProcessTypes.jrag:12")
  public Session type() {
    ASTState state = state();
    if (type_computed) {
      return type_value;
    }
    if (type_visited) {
      throw new RuntimeException("Circular definition of attribute Process.type().");
    }
    type_visited = true;
    state().enterLazyAttribute();
    type_value = type_compute();
    type_computed = true;
    state().leaveLazyAttribute();
    type_visited = false;
    return type_value;
  }
  /** @apilevel internal */
  private Session type_compute() {
          if(delegating().getName()!=null){
              Process p = getNextProcess(this);
              Process p1 = getNextProcess(p);
              Process p2 = getNextProcess(p1);
              Session next = getNextProcess(p2)!=null?getNextProcess(p2).type():null;
  
              Register reg1 = new Register(new List(new Atom(getModuleName()),new Call(new Atom("self"), new List())), null);
              Register reg2 = new Register(new List(delegating().getName(),new Call(new Atom("self"), new List())), null);
  
              boolean differ = !p.equals(p1);
              boolean b1 = this.equals(new Unregister(new List(delegating().getName()), null));
              boolean b2 = (p.equals(reg1) || p.equals(reg2));
              boolean b3 = (p1.equals(reg1) || p1.equals(reg2));
              boolean b4 = p2.equals(new Send(delegating().getName(),
                      new Message(new AtomSender(getModuleName()), new Atom("end_delegation"),new List()), null));
  
              if(b1 && b2 && b3 && b4 && differ){
                  return new RequestBackwardDelegation(delegating().getName(),next);
              }
          }
          return null;
      }

}
