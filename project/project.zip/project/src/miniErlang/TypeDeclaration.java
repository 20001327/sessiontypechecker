package miniErlang;

import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast class
 * @aspect TypeTable
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:4
 */
 class TypeDeclaration extends java.lang.Object {
  /**
   * @aspect TypeTable
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:5
   */
  
        String name;
  /**
   * @aspect TypeTable
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:6
   */
  
        Session type;
  /**
   * @aspect TypeTable
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:8
   */
  

        public String getName(){
            return name;
        }
  /**
   * @aspect TypeTable
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:12
   */
  

        public Session getType(){
            return type;
        }
  /**
   * @aspect TypeTable
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:16
   */
  

        public void setName(String name){
            this.name = name;
        }
  /**
   * @aspect TypeTable
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\TypeTable.jrag:20
   */
  

        public void setType(Session type){
            this.type = type;
        }

}
