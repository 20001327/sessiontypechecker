/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\FErlang.ast:12
 * @astdecl ReceiveClause : ASTNode ::= Sender:Atom Label:Atom Variables:Pattern* Actions:Process;
 * @production ReceiveClause : {@link ASTNode} ::= <span class="component">Sender:{@link Atom}</span> <span class="component">Label:{@link Atom}</span> <span class="component">Variables:{@link Pattern}*</span> <span class="component">Actions:{@link Process}</span>;

 */
public class ReceiveClause extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:324
   */
  public void print(){
       printer().append(indent() + PrettyPrinter.INDENT);
       printer().append("{");
       getSender().print();
       printer().append(",");
       getLabel().print();
       if(getNumVariables()>0)
            printer().append(",");
       for(int i=0; i<getNumVariables();i++){
            getVariables(i).print();
            if(i<getNumVariables()-1){
                printer().append(",");
            }
       }
       printer().append("}->");
       getActions().print();
    }
  /**
   * @aspect Equals
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\Equals.jrag:17
   */
  public boolean equals(Object other){
        if(this.getClass().getName().equals(other.getClass().getName())){
            ReceiveClause rc = (ReceiveClause) other;
            return rc.getLabel().equals(getLabel()) && rc.getSender().equals(getSender());
        }
        return false;
    }
  /**
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:38
   */
  public void addDeclaration(String name, Session type, Expression value) {
        VarDeclaration var = new VarDeclaration();
        var.setName(name);
        var.setType(type);
        var.setValue(value);
        getDeclarations().add(var);
    }
  /**
   * @declaredat ASTNode:1
   */
  public ReceiveClause() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[4];
    setChild(new List(), 2);
  }
  /**
   * @declaredat ASTNode:14
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Sender", "Label", "Variables", "Actions"},
    type = {"Atom", "Atom", "List<Pattern>", "Process"},
    kind = {"Child", "Child", "List", "Child"}
  )
  public ReceiveClause(Atom p0, Atom p1, List<Pattern> p2, Process p3) {
    setChild(p0, 0);
    setChild(p1, 1);
    setChild(p2, 2);
    setChild(p3, 3);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:26
   */
  protected int numChildren() {
    return 4;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:30
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    type_reset();
    getInfo_String_int_reset();
    getNextProcess_Process_reset();
    getModuleName_reset();
    delegating_reset();
    getModulesList_reset();
    printer_reset();
    getDeclarations_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:42
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:47
   */
  public ReceiveClause clone() throws CloneNotSupportedException {
    ReceiveClause node = (ReceiveClause) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:52
   */
  public ReceiveClause copy() {
    try {
      ReceiveClause node = (ReceiveClause) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:71
   */
  @Deprecated
  public ReceiveClause fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:81
   */
  public ReceiveClause treeCopyNoTransform() {
    ReceiveClause tree = (ReceiveClause) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:101
   */
  public ReceiveClause treeCopy() {
    ReceiveClause tree = (ReceiveClause) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the Sender child.
   * @param node The new node to replace the Sender child.
   * @apilevel high-level
   */
  public ReceiveClause setSender(Atom node) {
    setChild(node, 0);
    return this;
  }
  /**
   * Retrieves the Sender child.
   * @return The current node used as the Sender child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Sender")
  public Atom getSender() {
    return (Atom) getChild(0);
  }
  /**
   * Retrieves the Sender child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Sender child.
   * @apilevel low-level
   */
  public Atom getSenderNoTransform() {
    return (Atom) getChildNoTransform(0);
  }
  /**
   * Replaces the Label child.
   * @param node The new node to replace the Label child.
   * @apilevel high-level
   */
  public ReceiveClause setLabel(Atom node) {
    setChild(node, 1);
    return this;
  }
  /**
   * Retrieves the Label child.
   * @return The current node used as the Label child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Label")
  public Atom getLabel() {
    return (Atom) getChild(1);
  }
  /**
   * Retrieves the Label child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Label child.
   * @apilevel low-level
   */
  public Atom getLabelNoTransform() {
    return (Atom) getChildNoTransform(1);
  }
  /**
   * Replaces the Variables list.
   * @param list The new list node to be used as the Variables list.
   * @apilevel high-level
   */
  public ReceiveClause setVariablesList(List<Pattern> list) {
    setChild(list, 2);
    return this;
  }
  /**
   * Retrieves the number of children in the Variables list.
   * @return Number of children in the Variables list.
   * @apilevel high-level
   */
  public int getNumVariables() {
    return getVariablesList().getNumChild();
  }
  /**
   * Retrieves the number of children in the Variables list.
   * Calling this method will not trigger rewrites.
   * @return Number of children in the Variables list.
   * @apilevel low-level
   */
  public int getNumVariablesNoTransform() {
    return getVariablesListNoTransform().getNumChildNoTransform();
  }
  /**
   * Retrieves the element at index {@code i} in the Variables list.
   * @param i Index of the element to return.
   * @return The element at position {@code i} in the Variables list.
   * @apilevel high-level
   */
  public Pattern getVariables(int i) {
    return (Pattern) getVariablesList().getChild(i);
  }
  /**
   * Check whether the Variables list has any children.
   * @return {@code true} if it has at least one child, {@code false} otherwise.
   * @apilevel high-level
   */
  public boolean hasVariables() {
    return getVariablesList().getNumChild() != 0;
  }
  /**
   * Append an element to the Variables list.
   * @param node The element to append to the Variables list.
   * @apilevel high-level
   */
  public ReceiveClause addVariables(Pattern node) {
    List<Pattern> list = (parent == null) ? getVariablesListNoTransform() : getVariablesList();
    list.addChild(node);
    return this;
  }
  /** @apilevel low-level 
   */
  public ReceiveClause addVariablesNoTransform(Pattern node) {
    List<Pattern> list = getVariablesListNoTransform();
    list.addChild(node);
    return this;
  }
  /**
   * Replaces the Variables list element at index {@code i} with the new node {@code node}.
   * @param node The new node to replace the old list element.
   * @param i The list index of the node to be replaced.
   * @apilevel high-level
   */
  public ReceiveClause setVariables(Pattern node, int i) {
    List<Pattern> list = getVariablesList();
    list.setChild(node, i);
    return this;
  }
  /**
   * Retrieves the Variables list.
   * @return The node representing the Variables list.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.ListChild(name="Variables")
  public List<Pattern> getVariablesList() {
    List<Pattern> list = (List<Pattern>) getChild(2);
    return list;
  }
  /**
   * Retrieves the Variables list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Variables list.
   * @apilevel low-level
   */
  public List<Pattern> getVariablesListNoTransform() {
    return (List<Pattern>) getChildNoTransform(2);
  }
  /**
   * @return the element at index {@code i} in the Variables list without
   * triggering rewrites.
   */
  public Pattern getVariablesNoTransform(int i) {
    return (Pattern) getVariablesListNoTransform().getChildNoTransform(i);
  }
  /**
   * Retrieves the Variables list.
   * @return The node representing the Variables list.
   * @apilevel high-level
   */
  public List<Pattern> getVariabless() {
    return getVariablesList();
  }
  /**
   * Retrieves the Variables list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Variables list.
   * @apilevel low-level
   */
  public List<Pattern> getVariablessNoTransform() {
    return getVariablesListNoTransform();
  }
  /**
   * Replaces the Actions child.
   * @param node The new node to replace the Actions child.
   * @apilevel high-level
   */
  public ReceiveClause setActions(Process node) {
    setChild(node, 3);
    return this;
  }
  /**
   * Retrieves the Actions child.
   * @return The current node used as the Actions child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Actions")
  public Process getActions() {
    return (Process) getChild(3);
  }
  /**
   * Retrieves the Actions child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Actions child.
   * @apilevel low-level
   */
  public Process getActionsNoTransform() {
    return (Process) getChildNoTransform(3);
  }
/** @apilevel internal */
protected boolean type_visited = false;
  /** @apilevel internal */
  private void type_reset() {
    type_computed = false;
    
    type_value = null;
    type_visited = false;
  }
  /** @apilevel internal */
  protected boolean type_computed = false;

  /** @apilevel internal */
  protected Session type_value;

  /**
   * @attribute syn
   * @aspect ReceiveTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:43
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ReceiveTyping", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:5")
  public Session type() {
    ASTState state = state();
    if (type_computed) {
      return type_value;
    }
    if (type_visited) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.type().");
    }
    type_visited = true;
    state().enterLazyAttribute();
    type_value = type_compute();
    type_computed = true;
    state().leaveLazyAttribute();
    type_visited = false;
    return type_value;
  }
  /** @apilevel internal */
  private Session type_compute() {
         List<LiteralType> sessions = new List();
         if(getLabel().getIdent().equals("end_delegation")){
             return new AcceptBackwardDelegation(
              getSender(),getActions().type());
         }
  
         if(getNumVariables()>0){
             if(getNumVariables()==2){
                 if(getLabel().getIdent().
                      equals("start_delegation")){
                     Send s = searchSendInMod(getSender().getIdent(),
                          getModuleName(),getLabel().getIdent());
                     if(s.getMessage().getPayload(0).type().
                              isSameType(new AtomType()) &&
                         s.getMessage().getPayload(1).type().
                              isSameType(new PidType())){
                             Process p = getActions();
                             Process p1 = getNextProcess(p);
                             Process p2 = getNextProcess(p1);
                             for(int i=0; i<s.getMessage().getNumPayload();i++){
                                 addDeclaration(((Variable)getVariables(i)).getIdent(),
                                      s.getMessage().getPayload(i).type(),
                                      s.getMessage().getPayload(i));
                             }
  
                             Atom d = (Atom)s.getMessage().getPayload(0);
  
                             Unregister unreg1 = new Unregister(
                                  new List(new Atom(getModuleName()))
                                  ,null);
                             Unregister unreg2 = new Unregister( new List(d), null);
                             Register reg1 = new Register(
                                  new List(d,new Call(new Atom("self"),
                                      new List())), null);
  
                             boolean differ = !p.equals(p1);
                             boolean b1 = (p.equals(unreg1) || p.equals(unreg2));
                             boolean b2 = (p1.equals(unreg1) || p1.equals(unreg2));
                             boolean b3 = p2.equals(reg1);
  
                             if(b1 && b2 && b3 && differ){
                                  delegating().setName(d);
                                  return new AcceptForwardDelegation(d,
                                          getNextProcess(p2).type());
                             }
                         }
                 }
            }
  
             for(int i=0; i<getNumVariables();i++){
                 if(getVariables(i).getClass().getName().
                      equals(Variable.class.getName())){
                     addDeclaration(((Variable)getVariables(i)).getIdent(),
                                      getInfo(getLabel().getIdent(), i), null);
                 }
                 sessions.add((LiteralType)getVariables(i).type());
             }
         }
         return new SessionReceive(getSender(),getLabel(),sessions, getActions().type());
      }
/** @apilevel internal */
protected java.util.Set searchSendInMod_String_String_String_visited;
  /**
   * @attribute syn
   * @aspect ReceiveTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:105
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ReceiveTyping", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:105")
  public Send searchSendInMod(String moduleName, String dest, String label) {
    java.util.List _parameters = new java.util.ArrayList(3);
    _parameters.add(moduleName);
    _parameters.add(dest);
    _parameters.add(label);
    if (searchSendInMod_String_String_String_visited == null) searchSendInMod_String_String_String_visited = new java.util.HashSet(4);
    if (searchSendInMod_String_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.searchSendInMod(String,String,String).");
    }
    searchSendInMod_String_String_String_visited.add(_parameters);
    try {
            for (Module module: getModulesList()){
                if(module.getPartecipant().equals(moduleName)){
                    for(Function f: module.getFunctionss()){
                        return searchSend(f.getBody(), dest, label);
                    }
                }
            }
            return null;
        }
    finally {
      searchSendInMod_String_String_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected java.util.Set searchSend_Process_String_String_visited;
  /**
   * @attribute syn
   * @aspect ReceiveTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:117
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="ReceiveTyping", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:117")
  public Send searchSend(Process process, String dest, String label) {
    java.util.List _parameters = new java.util.ArrayList(3);
    _parameters.add(process);
    _parameters.add(dest);
    _parameters.add(label);
    if (searchSend_Process_String_String_visited == null) searchSend_Process_String_String_visited = new java.util.HashSet(4);
    if (searchSend_Process_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.searchSend(Process,String,String).");
    }
    searchSend_Process_String_String_visited.add(_parameters);
    try {
            String className = process.getClass().getName();
            if(className.equals(Send.class.getName())){
                Send s = (Send) process;
                if(s.getRecipient().getIdent().equals(dest)
                    && s.getMessage().getLabel().getIdent().equals(label)){
                    return s;
                }else {
                    return searchSend(s.getNext(),dest,label);
                }
            }else if(className.equals(Receive.class.getName())){
                Receive s = (Receive) process;
                Send send = null;
                for (ReceiveClause rc : s.getClausess()){
                    send = searchSend(rc.getActions(),dest,label);
                    if (send!=null) return send;
                }
                if(s.hasNext()) return searchSend(s.getNext(),dest,label);
            }else if(className.equals(Case.class.getName())){
                Case s = (Case) process;
                Send send = null;
                for (CaseClause rc : s.getClausess()){
                    send = searchSend(rc.getActions(),dest,label);
                    if (send!=null) return send;
                }
                if(s.hasNext()) return searchSend(s.getNext(),dest,label);
            }else if(className.equals(Let.class.getName())){
                Let s = (Let) process;
                return searchSend(s.getNext(),dest,label);
            }
    
            return null;
        }
    finally {
      searchSend_Process_String_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected boolean addsIndentationLevel_visited = false;
  /**
   * @attribute syn
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:49
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:44")
  public boolean addsIndentationLevel() {
    if (addsIndentationLevel_visited) {
      throw new RuntimeException("Circular definition of attribute ASTNode.addsIndentationLevel().");
    }
    addsIndentationLevel_visited = true;
    boolean addsIndentationLevel_value = true;
    addsIndentationLevel_visited = false;
    return addsIndentationLevel_value;
  }
  /**
   * @attribute inh
   * @aspect SessionTypesInformationUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:5
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="SessionTypesInformationUtility", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:5")
  public Session getInfo(String label, int index) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(label);
    _parameters.add(index);
    if (getInfo_String_int_visited == null) getInfo_String_int_visited = new java.util.HashSet(4);
    if (getInfo_String_int_values == null) getInfo_String_int_values = new java.util.HashMap(4);
    ASTState state = state();
    if (getInfo_String_int_values.containsKey(_parameters)) {
      return (Session) getInfo_String_int_values.get(_parameters);
    }
    if (getInfo_String_int_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.getInfo(String,int).");
    }
    getInfo_String_int_visited.add(_parameters);
    state().enterLazyAttribute();
    Session getInfo_String_int_value = getParent().Define_getInfo(this, null, label, index);
    getInfo_String_int_values.put(_parameters, getInfo_String_int_value);
    state().leaveLazyAttribute();
    getInfo_String_int_visited.remove(_parameters);
    return getInfo_String_int_value;
  }
/** @apilevel internal */
protected java.util.Set getInfo_String_int_visited;
  /** @apilevel internal */
  private void getInfo_String_int_reset() {
    getInfo_String_int_values = null;
    getInfo_String_int_visited = null;
  }
  /** @apilevel internal */
  protected java.util.Map getInfo_String_int_values;

  /**
   * @attribute inh
   * @aspect ReceiveTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:4
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ReceiveTyping", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:4")
  public Process getNextProcess(Process p) {
    Object _parameters = p;
    if (getNextProcess_Process_visited == null) getNextProcess_Process_visited = new java.util.HashSet(4);
    if (getNextProcess_Process_values == null) getNextProcess_Process_values = new java.util.HashMap(4);
    ASTState state = state();
    if (getNextProcess_Process_values.containsKey(_parameters)) {
      return (Process) getNextProcess_Process_values.get(_parameters);
    }
    if (getNextProcess_Process_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.getNextProcess(Process).");
    }
    getNextProcess_Process_visited.add(_parameters);
    state().enterLazyAttribute();
    Process getNextProcess_Process_value = getParent().Define_getNextProcess(this, null, p);
    getNextProcess_Process_values.put(_parameters, getNextProcess_Process_value);
    state().leaveLazyAttribute();
    getNextProcess_Process_visited.remove(_parameters);
    return getNextProcess_Process_value;
  }
/** @apilevel internal */
protected java.util.Set getNextProcess_Process_visited;
  /** @apilevel internal */
  private void getNextProcess_Process_reset() {
    getNextProcess_Process_values = null;
    getNextProcess_Process_visited = null;
  }
  /** @apilevel internal */
  protected java.util.Map getNextProcess_Process_values;

  /**
   * @attribute inh
   * @aspect ReceiveTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:6
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ReceiveTyping", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:6")
  public String getModuleName() {
    ASTState state = state();
    if (getModuleName_computed) {
      return getModuleName_value;
    }
    if (getModuleName_visited) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.getModuleName().");
    }
    getModuleName_visited = true;
    state().enterLazyAttribute();
    getModuleName_value = getParent().Define_getModuleName(this, null);
    getModuleName_computed = true;
    state().leaveLazyAttribute();
    getModuleName_visited = false;
    return getModuleName_value;
  }
/** @apilevel internal */
protected boolean getModuleName_visited = false;
  /** @apilevel internal */
  private void getModuleName_reset() {
    getModuleName_computed = false;
    
    getModuleName_value = null;
    getModuleName_visited = false;
  }
  /** @apilevel internal */
  protected boolean getModuleName_computed = false;

  /** @apilevel internal */
  protected String getModuleName_value;

  /**
   * @attribute inh
   * @aspect ReceiveTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:8
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ReceiveTyping", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:8")
  public Delegating delegating() {
    ASTState state = state();
    if (delegating_computed) {
      return delegating_value;
    }
    if (delegating_visited) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.delegating().");
    }
    delegating_visited = true;
    state().enterLazyAttribute();
    delegating_value = getParent().Define_delegating(this, null);
    delegating_computed = true;
    state().leaveLazyAttribute();
    delegating_visited = false;
    return delegating_value;
  }
/** @apilevel internal */
protected boolean delegating_visited = false;
  /** @apilevel internal */
  private void delegating_reset() {
    delegating_computed = false;
    
    delegating_value = null;
    delegating_visited = false;
  }
  /** @apilevel internal */
  protected boolean delegating_computed = false;

  /** @apilevel internal */
  protected Delegating delegating_value;

  /**
   * @attribute inh
   * @aspect ReceiveTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:12
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="ReceiveTyping", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:12")
  public List<Module> getModulesList() {
    ASTState state = state();
    if (getModulesList_computed) {
      return getModulesList_value;
    }
    if (getModulesList_visited) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.getModulesList().");
    }
    getModulesList_visited = true;
    state().enterLazyAttribute();
    getModulesList_value = getParent().Define_getModulesList(this, null);
    getModulesList_computed = true;
    state().leaveLazyAttribute();
    getModulesList_visited = false;
    return getModulesList_value;
  }
/** @apilevel internal */
protected boolean getModulesList_visited = false;
  /** @apilevel internal */
  private void getModulesList_reset() {
    getModulesList_computed = false;
    
    getModulesList_value = null;
    getModulesList_visited = false;
  }
  /** @apilevel internal */
  protected boolean getModulesList_computed = false;

  /** @apilevel internal */
  protected List<Module> getModulesList_value;

  /**
   * @attribute inh
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:66
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:66")
  public PrettyPrinter printer() {
    ASTState state = state();
    if (printer_computed) {
      return printer_value;
    }
    if (printer_visited) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.printer().");
    }
    printer_visited = true;
    state().enterLazyAttribute();
    printer_value = getParent().Define_printer(this, null);
    printer_computed = true;
    state().leaveLazyAttribute();
    printer_visited = false;
    return printer_value;
  }
/** @apilevel internal */
protected boolean printer_visited = false;
  /** @apilevel internal */
  private void printer_reset() {
    printer_computed = false;
    
    printer_value = null;
    printer_visited = false;
  }
  /** @apilevel internal */
  protected boolean printer_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter printer_value;

  /**
   * @attribute inh
   * @aspect NameAnalisys
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:56
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="NameAnalisys", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\u0075tils\\NameAnalisys.jrag:56")
  public ArrayList<VarDeclaration> getDeclarations() {
    ASTState state = state();
    if (getDeclarations_computed) {
      return getDeclarations_value;
    }
    if (getDeclarations_visited) {
      throw new RuntimeException("Circular definition of attribute ReceiveClause.getDeclarations().");
    }
    getDeclarations_visited = true;
    state().enterLazyAttribute();
    getDeclarations_value = getParent().Define_getDeclarations(this, null);
    getDeclarations_computed = true;
    state().leaveLazyAttribute();
    getDeclarations_visited = false;
    return getDeclarations_value;
  }
/** @apilevel internal */
protected boolean getDeclarations_visited = false;
  /** @apilevel internal */
  private void getDeclarations_reset() {
    getDeclarations_computed = false;
    
    getDeclarations_value = null;
    getDeclarations_visited = false;
  }
  /** @apilevel internal */
  protected boolean getDeclarations_computed = false;

  /** @apilevel internal */
  protected ArrayList<VarDeclaration> getDeclarations_value;

  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\CallTyping.jadd:2
   * @apilevel internal
   */
  public Delegating Define_delegating(ASTNode _callerNode, ASTNode _childNode) {
    if (_callerNode == getActionsNoTransform()) {
      // @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\process\\ReceiveTyping.jadd:9
      return this.delegating();
    }
    else {
      return getParent().Define_delegating(this, _callerNode);
    }
  }
  /**
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\expression\\CallTyping.jadd:2
   * @apilevel internal
   * @return {@code true} if this node has an equation for the inherited attribute delegating
   */
  protected boolean canDefine_delegating(ASTNode _callerNode, ASTNode _childNode) {
    return true;
  }

}
