/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\Session.ast:2
 * @astdecl Session : ASTNode;
 * @production Session : {@link ASTNode};

 */
public abstract class Session extends ASTNode<ASTNode> implements Cloneable {
  /**
   * @aspect EndsWithUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\EndsWithUtility.jrag:3
   */
  public abstract boolean endsWith(RecVar var);
  /**
   * @aspect SessionTypesInformationUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:15
   */
  public Session getInfo(String label,int index){
        return null;
    }
  /**
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:408
   */
  public void print(){
       printer().append("session");
    }
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:12
   */
  public abstract void stampa();
  /**
   * @aspect Merge
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\merge\\Merge.jadd:5
   */
  public static List<SessionReceive> merge(List<Session> sessions){
        List<SessionReceive> recs = new List();
        boolean allSimple = true;
        boolean allConnecting = true;

        Map<String, String> map = new HashMap();

        for(int i = 0; i<sessions.getNumChild();i++){
              if(sessions.getChild(i).isSubtypeOf(new ExternalChoice())){
                  ExternalChoice ext = (ExternalChoice)sessions.getChild(i);
                  for(SessionReceive r: ext.getReceivess()){
                    if(!r.isReceivePresentInThisMap(map)) recs.add(r);
                  }
              }else if(sessions.getChild(i).isSubtypeOf(new SessionReceive())){
                  SessionReceive r = (SessionReceive)sessions.getChild(i);
                  if(!r.isReceivePresentInThisMap(map)) recs.add(r);
              }
        }

        return recs;
    }
  /**
   * @aspect SessionComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\SessionComparison.jrag:10
   */
  public abstract boolean subtypeOf(Object other);
  /**
   * @aspect TypesComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\TypesComparison.jrag:2
   */
  public abstract boolean isSubtypeOf(Session t);
  /**
   * @aspect TypesComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\TypesComparison.jrag:3
   */
  public boolean isSameType(Session t) {
        return isSubtypeOf(t);
    }
  /**
   * @aspect InternalChoiceValidation
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\validation\\InternalChoiceValidation.jrag:42
   */
  public boolean isPresentInThisMap(Map<String,String> map){
        System.out.println("session: " + getClass().toString());
        return true;
    }
  /**
   * @declaredat ASTNode:1
   */
  public Session() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:13
   */
  protected int numChildren() {
    return 0;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:17
   */
  public void flushAttrCache() {
    super.flushAttrCache();
    printer_reset();
    stampante_reset();
  }
  /** @apilevel internal 
   * @declaredat ASTNode:23
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:28
   */
  public Session clone() throws CloneNotSupportedException {
    Session node = (Session) super.clone();
    return node;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:39
   */
  @Deprecated
  public abstract Session fullCopy();
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:47
   */
  public abstract Session treeCopyNoTransform();
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:55
   */
  public abstract Session treeCopy();
  /**
   * @attribute inh
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:64
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="PrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:64")
  public PrettyPrinter printer() {
    ASTState state = state();
    if (printer_computed) {
      return printer_value;
    }
    if (printer_visited) {
      throw new RuntimeException("Circular definition of attribute Session.printer().");
    }
    printer_visited = true;
    state().enterLazyAttribute();
    printer_value = getParent().Define_printer(this, null);
    printer_computed = true;
    state().leaveLazyAttribute();
    printer_visited = false;
    return printer_value;
  }
/** @apilevel internal */
protected boolean printer_visited = false;
  /** @apilevel internal */
  private void printer_reset() {
    printer_computed = false;
    
    printer_value = null;
    printer_visited = false;
  }
  /** @apilevel internal */
  protected boolean printer_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter printer_value;

  /**
   * @attribute inh
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.INH)
  @ASTNodeAnnotation.Source(aspect="SessionPrettyPrint", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:9")
  public PrettyPrinter stampante() {
    ASTState state = state();
    if (stampante_computed) {
      return stampante_value;
    }
    if (stampante_visited) {
      throw new RuntimeException("Circular definition of attribute Session.stampante().");
    }
    stampante_visited = true;
    state().enterLazyAttribute();
    stampante_value = getParent().Define_stampante(this, null);
    stampante_computed = true;
    state().leaveLazyAttribute();
    stampante_visited = false;
    return stampante_value;
  }
/** @apilevel internal */
protected boolean stampante_visited = false;
  /** @apilevel internal */
  private void stampante_reset() {
    stampante_computed = false;
    
    stampante_value = null;
    stampante_visited = false;
  }
  /** @apilevel internal */
  protected boolean stampante_computed = false;

  /** @apilevel internal */
  protected PrettyPrinter stampante_value;


}
