/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\Session.ast:5
 * @astdecl InternalChoice : Session ::= Sends:SessionSend*;
 * @production InternalChoice : {@link Session} ::= <span class="component">Sends:{@link SessionSend}*</span>;

 */
public class InternalChoice extends Session implements Cloneable {
  /**
   * @aspect EndsWithUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\EndsWithUtility.jrag:13
   */
  public boolean endsWith(RecVar var){
      boolean found = false;
      for (SessionSend send: getSendss()){
        found = found || send.endsWith(var);
      }
      return found;
    }
  /**
   * @aspect SessionTypesInformationUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\SessionTypesInformationUtility.jrag:53
   */
  public Session getInfo(String label,int index){
        if(!this.isWellFormed()){
            return null;
        }

        if(getNumSends()>0){
            for (int i=0; i<getNumSends(); i++) {
                if(getSends(i).getInfo(label, index)!=null){
                    return getSends(i).getInfo(label, index);
                }
            }
        }

        return null;
    }
  /**
   * @aspect PrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\PrettyPrint.jrag:171
   */
  public void print(){
        printer().append("@(");
        if(getNumSends()>0){
            for (int i=0; i<getNumSends(); i++) {
                getSends(i).print();
                if(i<getNumSends()-1){
                    printer().append(",");
                }
            }
        }
        printer().append(")");
    }
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:94
   */
  public void stampa(){
        stampante().append("@(");
        if(getNumSends()>0){
            for (int i=0; i<getNumSends(); i++) {
                getSends(i).stampa();
                if(i<getNumSends()-1){
                    stampante().append(",");
                }
            }
        }
        stampante().append(")");
    }
  /**
   * @aspect TypesComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\TypesComparison.jrag:59
   */
  public boolean isSubtypeOf(Session t) {
            return t instanceof InternalChoice;
    }
  /**
   * @aspect InternalChoiceSubTyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\session\\InternalChoiceSubtyping.jadd:2
   */
  public boolean subtypeOf(Object other){
                  if(Program.sameClass(this, other)){
                  InternalChoice obj = (InternalChoice) other;
                  boolean foundAll = true;
                  for (SessionSend send: getSendss()){
                    boolean found = false;
                    for (SessionSend s2 : obj.getSendss()){
                      found = found || send.subtypeOf(s2);
                    }
                    foundAll = found && foundAll;
                  }
                  return foundAll;
              }
            return false;
        }
  /**
   * @aspect InternalChoiceValidation
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\validation\\InternalChoiceValidation.jrag:55
   */
  public boolean isPresentInThisMap(Map<String,String> map){
        return false;
    }
  /**
   * @declaredat ASTNode:1
   */
  public InternalChoice() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[1];
    setChild(new List(), 0);
  }
  /**
   * @declaredat ASTNode:14
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Sends"},
    type = {"List<SessionSend>"},
    kind = {"List"}
  )
  public InternalChoice(List<SessionSend> p0) {
    setChild(p0, 0);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:23
   */
  protected int numChildren() {
    return 1;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:27
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:32
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:37
   */
  public InternalChoice clone() throws CloneNotSupportedException {
    InternalChoice node = (InternalChoice) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:42
   */
  public InternalChoice copy() {
    try {
      InternalChoice node = (InternalChoice) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:61
   */
  @Deprecated
  public InternalChoice fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:71
   */
  public InternalChoice treeCopyNoTransform() {
    InternalChoice tree = (InternalChoice) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:91
   */
  public InternalChoice treeCopy() {
    InternalChoice tree = (InternalChoice) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the Sends list.
   * @param list The new list node to be used as the Sends list.
   * @apilevel high-level
   */
  public InternalChoice setSendsList(List<SessionSend> list) {
    setChild(list, 0);
    return this;
  }
  /**
   * Retrieves the number of children in the Sends list.
   * @return Number of children in the Sends list.
   * @apilevel high-level
   */
  public int getNumSends() {
    return getSendsList().getNumChild();
  }
  /**
   * Retrieves the number of children in the Sends list.
   * Calling this method will not trigger rewrites.
   * @return Number of children in the Sends list.
   * @apilevel low-level
   */
  public int getNumSendsNoTransform() {
    return getSendsListNoTransform().getNumChildNoTransform();
  }
  /**
   * Retrieves the element at index {@code i} in the Sends list.
   * @param i Index of the element to return.
   * @return The element at position {@code i} in the Sends list.
   * @apilevel high-level
   */
  public SessionSend getSends(int i) {
    return (SessionSend) getSendsList().getChild(i);
  }
  /**
   * Check whether the Sends list has any children.
   * @return {@code true} if it has at least one child, {@code false} otherwise.
   * @apilevel high-level
   */
  public boolean hasSends() {
    return getSendsList().getNumChild() != 0;
  }
  /**
   * Append an element to the Sends list.
   * @param node The element to append to the Sends list.
   * @apilevel high-level
   */
  public InternalChoice addSends(SessionSend node) {
    List<SessionSend> list = (parent == null) ? getSendsListNoTransform() : getSendsList();
    list.addChild(node);
    return this;
  }
  /** @apilevel low-level 
   */
  public InternalChoice addSendsNoTransform(SessionSend node) {
    List<SessionSend> list = getSendsListNoTransform();
    list.addChild(node);
    return this;
  }
  /**
   * Replaces the Sends list element at index {@code i} with the new node {@code node}.
   * @param node The new node to replace the old list element.
   * @param i The list index of the node to be replaced.
   * @apilevel high-level
   */
  public InternalChoice setSends(SessionSend node, int i) {
    List<SessionSend> list = getSendsList();
    list.setChild(node, i);
    return this;
  }
  /**
   * Retrieves the Sends list.
   * @return The node representing the Sends list.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.ListChild(name="Sends")
  public List<SessionSend> getSendsList() {
    List<SessionSend> list = (List<SessionSend>) getChild(0);
    return list;
  }
  /**
   * Retrieves the Sends list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Sends list.
   * @apilevel low-level
   */
  public List<SessionSend> getSendsListNoTransform() {
    return (List<SessionSend>) getChildNoTransform(0);
  }
  /**
   * @return the element at index {@code i} in the Sends list without
   * triggering rewrites.
   */
  public SessionSend getSendsNoTransform(int i) {
    return (SessionSend) getSendsListNoTransform().getChildNoTransform(i);
  }
  /**
   * Retrieves the Sends list.
   * @return The node representing the Sends list.
   * @apilevel high-level
   */
  public List<SessionSend> getSendss() {
    return getSendsList();
  }
  /**
   * Retrieves the Sends list.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The node representing the Sends list.
   * @apilevel low-level
   */
  public List<SessionSend> getSendssNoTransform() {
    return getSendsListNoTransform();
  }
/** @apilevel internal */
protected boolean isWellFormed_visited = false;
  /**
   * @attribute syn
   * @aspect InternalChoiceValidation
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\validation\\InternalChoiceValidation.jrag:6
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="InternalChoiceValidation", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\validation\\InternalChoiceValidation.jrag:6")
  public boolean isWellFormed() {
    if (isWellFormed_visited) {
      throw new RuntimeException("Circular definition of attribute InternalChoice.isWellFormed().");
    }
    isWellFormed_visited = true;
    try {
            Map<String, String> map = new HashMap();
    
            for(SessionSend send: getSendss()){
                if(send.isPresentInThisMap(map)){
                    return false;
                }
            }
    
            return true;
        }
    finally {
      isWellFormed_visited = false;
    }
  }

}
