/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\Session.ast:12
 * @astdecl RecVar : Session ::= <Name:String>;
 * @production RecVar : {@link Session} ::= <span class="component">&lt;Name:{@link String}&gt;</span>;

 */
public class RecVar extends Session implements Cloneable {
  /**
   * @aspect EndsWithUtility
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\erlangtyping\\EndsWithUtility.jrag:5
   */
  public boolean endsWith(RecVar var){
        return this.getName().equals(var.getName());
    }
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\SessionPrettyPrint.jrag:21
   */
  public void stampa(){
        stampante().append("$");
        stampante().append(getName());
    }
  /**
   * @aspect TypesComparison
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\TypesComparison.jrag:15
   */
  public boolean isSubtypeOf(Session t) {
            return t instanceof RecVar;
    }
  /**
   * @aspect RecSubtyping
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\subtyping\\session\\RecSubtyping.jadd:13
   */
  public boolean subtypeOf(Object other){
        return ((Session)other).isSubtypeOf(new RecVar());
    }
  /**
   * @aspect InternalChoiceValidation
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\validation\\InternalChoiceValidation.jrag:47
   */
  public boolean isPresentInThisMap(Map<String,String> map){
        return false;
    }
  /**
   * @declaredat ASTNode:1
   */
  public RecVar() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
  }
  /**
   * @declaredat ASTNode:12
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Name"},
    type = {"String"},
    kind = {"Token"}
  )
  public RecVar(String p0) {
    setName(p0);
  }
  /**
   * @declaredat ASTNode:20
   */
  public RecVar(beaver.Symbol p0) {
    setName(p0);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:24
   */
  protected int numChildren() {
    return 0;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:28
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:33
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:38
   */
  public RecVar clone() throws CloneNotSupportedException {
    RecVar node = (RecVar) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:43
   */
  public RecVar copy() {
    try {
      RecVar node = (RecVar) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:62
   */
  @Deprecated
  public RecVar fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:72
   */
  public RecVar treeCopyNoTransform() {
    RecVar tree = (RecVar) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:92
   */
  public RecVar treeCopy() {
    RecVar tree = (RecVar) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the lexeme Name.
   * @param value The new value for the lexeme Name.
   * @apilevel high-level
   */
  public RecVar setName(String value) {
    tokenString_Name = value;
    return this;
  }
  /** @apilevel internal 
   */
  protected String tokenString_Name;
  /**
   */
  public int Namestart;
  /**
   */
  public int Nameend;
  /**
   * JastAdd-internal setter for lexeme Name using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme Name
   * @apilevel internal
   */
  public RecVar setName(beaver.Symbol symbol) {
    if (symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setName is only valid for String lexemes");
    tokenString_Name = (String)symbol.value;
    Namestart = symbol.getStart();
    Nameend = symbol.getEnd();
    return this;
  }
  /**
   * Retrieves the value for the lexeme Name.
   * @return The value for the lexeme Name.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="Name")
  public String getName() {
    return tokenString_Name != null ? tokenString_Name : "";
  }

}
