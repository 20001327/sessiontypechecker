/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\GlobalTypes.ast:6
 * @astdecl StartDelegation : Global ::= <Delegate:String> <Delegating:String> Next:Global;
 * @production StartDelegation : {@link Global} ::= <span class="component">&lt;Delegate:{@link String}&gt;</span> <span class="component">&lt;Delegating:{@link String}&gt;</span> <span class="component">Next:{@link Global}</span>;

 */
public class StartDelegation extends Global implements Cloneable {
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:88
   */
  public void stampa(){
        stampante().append("\n");
        stampante().append(getDelegating());
        stampante().append("<<");
        stampante().append(getDelegate());
        stampante().append(".");
        getNext().stampa();
    }
  /**
   * @aspect ActorDiscover
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\ActorDiscover.jrag:55
   */
  public ArrayList<String> actors(){
        ArrayList<String> actors = new ArrayList();
        GProg.addAbsent(getDelegating(),actors);
        GProg.addAbsent(getDelegate(),actors);

        for(String actor: getNext().actors()){
            GProg.addAbsent(actor, actors);
        }

        return actors;
    }
  /**
   * @declaredat ASTNode:1
   */
  public StartDelegation() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[1];
  }
  /**
   * @declaredat ASTNode:13
   */
  @ASTNodeAnnotation.Constructor(
    name = {"Delegate", "Delegating", "Next"},
    type = {"String", "String", "Global"},
    kind = {"Token", "Token", "Child"}
  )
  public StartDelegation(String p0, String p1, Global p2) {
    setDelegate(p0);
    setDelegating(p1);
    setChild(p2, 0);
  }
  /**
   * @declaredat ASTNode:23
   */
  public StartDelegation(beaver.Symbol p0, beaver.Symbol p1, Global p2) {
    setDelegate(p0);
    setDelegating(p1);
    setChild(p2, 0);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:29
   */
  protected int numChildren() {
    return 1;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:33
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:38
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:43
   */
  public StartDelegation clone() throws CloneNotSupportedException {
    StartDelegation node = (StartDelegation) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:48
   */
  public StartDelegation copy() {
    try {
      StartDelegation node = (StartDelegation) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:67
   */
  @Deprecated
  public StartDelegation fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:77
   */
  public StartDelegation treeCopyNoTransform() {
    StartDelegation tree = (StartDelegation) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:97
   */
  public StartDelegation treeCopy() {
    StartDelegation tree = (StartDelegation) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the lexeme Delegate.
   * @param value The new value for the lexeme Delegate.
   * @apilevel high-level
   */
  public StartDelegation setDelegate(String value) {
    tokenString_Delegate = value;
    return this;
  }
  /** @apilevel internal 
   */
  protected String tokenString_Delegate;
  /**
   */
  public int Delegatestart;
  /**
   */
  public int Delegateend;
  /**
   * JastAdd-internal setter for lexeme Delegate using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme Delegate
   * @apilevel internal
   */
  public StartDelegation setDelegate(beaver.Symbol symbol) {
    if (symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setDelegate is only valid for String lexemes");
    tokenString_Delegate = (String)symbol.value;
    Delegatestart = symbol.getStart();
    Delegateend = symbol.getEnd();
    return this;
  }
  /**
   * Retrieves the value for the lexeme Delegate.
   * @return The value for the lexeme Delegate.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="Delegate")
  public String getDelegate() {
    return tokenString_Delegate != null ? tokenString_Delegate : "";
  }
  /**
   * Replaces the lexeme Delegating.
   * @param value The new value for the lexeme Delegating.
   * @apilevel high-level
   */
  public StartDelegation setDelegating(String value) {
    tokenString_Delegating = value;
    return this;
  }
  /** @apilevel internal 
   */
  protected String tokenString_Delegating;
  /**
   */
  public int Delegatingstart;
  /**
   */
  public int Delegatingend;
  /**
   * JastAdd-internal setter for lexeme Delegating using the Beaver parser.
   * @param symbol Symbol containing the new value for the lexeme Delegating
   * @apilevel internal
   */
  public StartDelegation setDelegating(beaver.Symbol symbol) {
    if (symbol.value != null && !(symbol.value instanceof String))
    throw new UnsupportedOperationException("setDelegating is only valid for String lexemes");
    tokenString_Delegating = (String)symbol.value;
    Delegatingstart = symbol.getStart();
    Delegatingend = symbol.getEnd();
    return this;
  }
  /**
   * Retrieves the value for the lexeme Delegating.
   * @return The value for the lexeme Delegating.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Token(name="Delegating")
  public String getDelegating() {
    return tokenString_Delegating != null ? tokenString_Delegating : "";
  }
  /**
   * Replaces the Next child.
   * @param node The new node to replace the Next child.
   * @apilevel high-level
   */
  public StartDelegation setNext(Global node) {
    setChild(node, 0);
    return this;
  }
  /**
   * Retrieves the Next child.
   * @return The current node used as the Next child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Next")
  public Global getNext() {
    return (Global) getChild(0);
  }
  /**
   * Retrieves the Next child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Next child.
   * @apilevel low-level
   */
  public Global getNextNoTransform() {
    return (Global) getChildNoTransform(0);
  }
/** @apilevel internal */
protected java.util.Set project_String_visited;
  /**
   * @attribute syn
   * @aspect DelegationProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\DelegationProjection.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="DelegationProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\DelegationProjection.jadd:3")
  public Session project(String actor) {
    Object _parameters = actor;
    if (project_String_visited == null) project_String_visited = new java.util.HashSet(4);
    if (project_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute StartDelegation.project(String).");
    }
    project_String_visited.add(_parameters);
    try {
            if(getDelegating().equals(actor)){
                return new RequestForwardDelegation(new Atom(getDelegate()), getNext().projectDelegating(getDelegating(),getDelegate()));
            }else if(getDelegate().equals(actor)){
                return new AcceptForwardDelegation(new Atom(getDelegating()), getNext().projectDelegate(getDelegating(), getDelegate()));
            }
    
            return getNext().project(actor);
        }
    finally {
      project_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected java.util.Set projectDelegate_String_String_visited;
  /**
   * @attribute syn
   * @aspect DelegationDelegateProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\DelegationDelegateProjection.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="DelegationDelegateProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegate\\DelegationDelegateProjection.jadd:3")
  public Session projectDelegate(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegate_String_String_visited == null) projectDelegate_String_String_visited = new java.util.HashSet(4);
    if (projectDelegate_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute StartDelegation.projectDelegate(String,String).");
    }
    projectDelegate_String_String_visited.add(_parameters);
    try {
            if(!p.equals(getDelegate()) && !p.equals(getDelegating()) &&
                    !q.equals(getDelegate()) && !q.equals(getDelegating())){
                return getNext().projectDelegate(p,q);
            }
            return null;
        }
    finally {
      projectDelegate_String_String_visited.remove(_parameters);
    }
  }
/** @apilevel internal */
protected java.util.Set projectDelegating_String_String_visited;
  /**
   * @attribute syn
   * @aspect DelegationDelegatingProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\DelegationDelegatingProjection.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="DelegationDelegatingProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\delegating\\DelegationDelegatingProjection.jadd:3")
  public Session projectDelegating(String p, String q) {
    java.util.List _parameters = new java.util.ArrayList(2);
    _parameters.add(p);
    _parameters.add(q);
    if (projectDelegating_String_String_visited == null) projectDelegating_String_String_visited = new java.util.HashSet(4);
    if (projectDelegating_String_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute StartDelegation.projectDelegating(String,String).");
    }
    projectDelegating_String_String_visited.add(_parameters);
    try {
            if(!p.equals(getDelegate()) && !p.equals(getDelegating()) &&
                    !q.equals(getDelegate()) && !q.equals(getDelegating())){
                return getNext().projectDelegating(p,q);
            }
            return null;
        }
    finally {
      projectDelegating_String_String_visited.remove(_parameters);
    }
  }

}
