/* This file was generated with JastAdd2 (http://jastadd.org) version 2.3.4-48-g8abc63a */
package miniErlang;
import java.util.stream.Collectors;
import java.util.HashMap;
import miniErlang.Expression;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.Map;
/**
 * @ast node
 * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\GlobalTypes.ast:8
 * @astdecl RecGlobal : Global ::= RecVariable:RecGlobalVar Type:Global;
 * @production RecGlobal : {@link Global} ::= <span class="component">RecVariable:{@link RecGlobalVar}</span> <span class="component">Type:{@link Global}</span>;

 */
public class RecGlobal extends Global implements Cloneable {
  /**
   * @aspect SessionPrettyPrint
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\print\\GlobalPrettyPrint.jrag:39
   */
  public void stampa(){
       stampante().append("rec");
       getRecVariable().stampa();
       stampante().append(".");
       getType().stampa();
    }
  /**
   * @aspect ActorDiscover
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\ActorDiscover.jrag:39
   */
  public ArrayList<String> actors(){
        ArrayList<String> actors = new ArrayList();
        for(String actor: getType().actors()){
            GProg.addAbsent(actor, actors);
        }
        return actors;
    }
  /**
   * @declaredat ASTNode:1
   */
  public RecGlobal() {
    super();
  }
  /**
   * Initializes the child array to the correct size.
   * Initializes List and Opt nta children.
   * @apilevel internal
   * @ast method
   * @declaredat ASTNode:10
   */
  public void init$Children() {
    children = new ASTNode[2];
  }
  /**
   * @declaredat ASTNode:13
   */
  @ASTNodeAnnotation.Constructor(
    name = {"RecVariable", "Type"},
    type = {"RecGlobalVar", "Global"},
    kind = {"Child", "Child"}
  )
  public RecGlobal(RecGlobalVar p0, Global p1) {
    setChild(p0, 0);
    setChild(p1, 1);
  }
  /** @apilevel low-level 
   * @declaredat ASTNode:23
   */
  protected int numChildren() {
    return 2;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:27
   */
  public void flushAttrCache() {
    super.flushAttrCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:32
   */
  public void flushCollectionCache() {
    super.flushCollectionCache();

  }
  /** @apilevel internal 
   * @declaredat ASTNode:37
   */
  public RecGlobal clone() throws CloneNotSupportedException {
    RecGlobal node = (RecGlobal) super.clone();
    return node;
  }
  /** @apilevel internal 
   * @declaredat ASTNode:42
   */
  public RecGlobal copy() {
    try {
      RecGlobal node = (RecGlobal) clone();
      node.parent = null;
      if (children != null) {
        node.children = (ASTNode[]) children.clone();
      }
      return node;
    } catch (CloneNotSupportedException e) {
      throw new Error("Error: clone not supported for " + getClass().getName());
    }
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @deprecated Please use treeCopy or treeCopyNoTransform instead
   * @declaredat ASTNode:61
   */
  @Deprecated
  public RecGlobal fullCopy() {
    return treeCopyNoTransform();
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:71
   */
  public RecGlobal treeCopyNoTransform() {
    RecGlobal tree = (RecGlobal) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) children[i];
        if (child != null) {
          child = child.treeCopyNoTransform();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Create a deep copy of the AST subtree at this node.
   * The subtree of this node is traversed to trigger rewrites before copy.
   * The copy is dangling, i.e. has no parent.
   * @return dangling copy of the subtree at this node
   * @apilevel low-level
   * @declaredat ASTNode:91
   */
  public RecGlobal treeCopy() {
    RecGlobal tree = (RecGlobal) copy();
    if (children != null) {
      for (int i = 0; i < children.length; ++i) {
        ASTNode child = (ASTNode) getChild(i);
        if (child != null) {
          child = child.treeCopy();
          tree.setChild(child, i);
        }
      }
    }
    return tree;
  }
  /**
   * Replaces the RecVariable child.
   * @param node The new node to replace the RecVariable child.
   * @apilevel high-level
   */
  public RecGlobal setRecVariable(RecGlobalVar node) {
    setChild(node, 0);
    return this;
  }
  /**
   * Retrieves the RecVariable child.
   * @return The current node used as the RecVariable child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="RecVariable")
  public RecGlobalVar getRecVariable() {
    return (RecGlobalVar) getChild(0);
  }
  /**
   * Retrieves the RecVariable child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the RecVariable child.
   * @apilevel low-level
   */
  public RecGlobalVar getRecVariableNoTransform() {
    return (RecGlobalVar) getChildNoTransform(0);
  }
  /**
   * Replaces the Type child.
   * @param node The new node to replace the Type child.
   * @apilevel high-level
   */
  public RecGlobal setType(Global node) {
    setChild(node, 1);
    return this;
  }
  /**
   * Retrieves the Type child.
   * @return The current node used as the Type child.
   * @apilevel high-level
   */
  @ASTNodeAnnotation.Child(name="Type")
  public Global getType() {
    return (Global) getChild(1);
  }
  /**
   * Retrieves the Type child.
   * <p><em>This method does not invoke AST transformations.</em></p>
   * @return The current node used as the Type child.
   * @apilevel low-level
   */
  public Global getTypeNoTransform() {
    return (Global) getChildNoTransform(1);
  }
/** @apilevel internal */
protected java.util.Set project_String_visited;
  /**
   * @attribute syn
   * @aspect RecursionProjection
   * @declaredat C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\RecursionProjection.jadd:3
   */
  @ASTNodeAnnotation.Attribute(kind=ASTNodeAnnotation.Kind.SYN)
  @ASTNodeAnnotation.Source(aspect="RecursionProjection", declaredAt="C:\\Users\\Lorenzo\\IdeaProjects\\SessionTypechecker\\project\\spec\\jrag\\projection\\RecursionProjection.jadd:3")
  public Session project(String actor) {
    Object _parameters = actor;
    if (project_String_visited == null) project_String_visited = new java.util.HashSet(4);
    if (project_String_visited.contains(_parameters)) {
      throw new RuntimeException("Circular definition of attribute RecGlobal.project(String).");
    }
    project_String_visited.add(_parameters);
    try {
            boolean found = false;
            for(String a: actors()){
                found = found || a.equals(actor);
            }
    
            Session s = getType().project(actor);
            if(found){
                RecVar recvar = new RecVar(getRecVariable().getName());
                if(s.endsWith(recvar)){
                    return new RecType(recvar, s);
                }
            }else{
                return s;
            }
    
            return new End();
        }
    finally {
      project_String_visited.remove(_parameters);
    }
  }

}
